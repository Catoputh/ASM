//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package asm;

import java.util.Vector;

public class Agent {
    static double minstrength;
    public double demand;
    public double profit;
    public double wealth;
    public double position;
    public double cash;
    public double initialcash;
    public double minholding;
    public double mincash;
    public double intrate;
    public double intratep1;
    public double price;
    public double dividend;
    public int myID;
    int currentTime;
    int lastgatime;
    double avspecificity;
    double forecast;
    double lforecast;
    double global_mean;
    double realDeviation;
    double variance;
    double pdcoeff;
    double offset;
    double divisor;
    int gacount;
    AgentParam privateParams;
    Vector fcastList;
    Vector activeList;
    Vector oldActiveList;
    Vector History;
    World worldForAgent;
    AsmModel local;

    void setBFParameterObject(AgentParam x) {
        this.privateParams = x;
    }

    void setWorld(World aWorld) {
        this.worldForAgent = aWorld;
    }

    void setintrate(double rate) {
        this.intrate = rate;
        this.intratep1 = this.intrate + 1.0D;
    }

    void setminHolding(double holding, double minimumcash) {
        this.minholding = holding;
        this.mincash = minimumcash;
    }

    void setInitialHoldings() {
        this.profit = 0.0D;
        this.wealth = 0.0D;
        this.cash = this.initialcash;
        this.position = 0.0D;
    }

    void getPriceFromWorld() {
        this.price = this.worldForAgent.getPrice();
    }

    void getDividendFromWorld() {
        this.dividend = this.worldForAgent.getDividend();
    }

    void creditEarningsAndPayTaxes() {
        this.getPriceFromWorld();
        this.getDividendFromWorld();
        this.cash -= (this.price * this.intrate - this.dividend) * this.position;
        if (this.cash < this.mincash) {
            this.cash = this.mincash;
        }

        this.wealth = this.cash + this.price * this.position;
    }

    double constrainDemand(double[] slope, double trialprice) {
        if (this.demand > 0.0D) {
            if (this.demand * trialprice > this.cash - this.mincash) {
                if (this.cash - this.mincash > 0.0D) {
                    this.demand = (this.cash - this.mincash) / trialprice;
                    slope[0] = -this.demand / trialprice;
                } else {
                    this.demand = 0.0D;
                    slope[0] = 0.0D;
                }
            }
        } else if (this.demand < 0.0D && this.demand + this.position < this.minholding) {
            this.demand = this.minholding - this.position;
            slope[0] = 0.0D;
        }

        return this.demand;
    }

    void initForecasts() {
        int sumspecificity = 0;
        new Forecast(this.privateParams.condbits);
        int numfcasts = this.privateParams.numfcasts;
        this.avspecificity = 0.0D;
        this.gacount = 0;
        this.variance = this.privateParams.initvar;
        this.getPriceFromWorld();
        this.getDividendFromWorld();
        this.global_mean = this.price + this.dividend;
        this.forecast = this.lforecast = this.global_mean;

        int i;
        Forecast aForecast;
        for(i = 0; i < numfcasts; ++i) {
            aForecast = this.createNewForecast();
            this.setConditionsRandomly(aForecast);
            this.fcastList.addElement(aForecast);
        }

        int size = this.fcastList.size();

        for(i = 0; i < size; ++i) {
            aForecast = (Forecast)this.fcastList.elementAt(i);
            sumspecificity += aForecast.specificity;
        }

        this.avspecificity = (double)sumspecificity / (double)numfcasts;
    }

    Forecast createNewForecast() {
        Forecast aForecast = new Forecast(this.privateParams.condbits);
        double abase = this.privateParams.a_min + 0.5D * (1.0D - this.privateParams.subrange) * this.privateParams.a_range;
        double bbase = this.privateParams.b_min + 0.5D * (1.0D - this.privateParams.subrange) * this.privateParams.b_range;
        double cbase = this.privateParams.c_min + 0.5D * (1.0D - this.privateParams.subrange) * this.privateParams.c_range;
        double asubrange = this.privateParams.subrange * this.privateParams.a_range;
        double bsubrange = this.privateParams.subrange * this.privateParams.b_range;
        double csubrange = this.privateParams.subrange * this.privateParams.c_range;
        aForecast.a = abase + Math.random() * asubrange;
        aForecast.b = bbase + Math.random() * bsubrange;
        aForecast.c = cbase + Math.random() * csubrange;
        aForecast.condbits = this.privateParams.condbits;
        aForecast.nnulls = this.privateParams.nnulls;
        aForecast.bitcost = this.privateParams.bitcost;
        aForecast.forecast = 0.0D;
        aForecast.lforecast = this.global_mean;
        aForecast.variance = this.privateParams.newfcastvar;
        aForecast.strength = 0.0D;
        return aForecast;
    }

    void setConditionsRandomly(Forecast fcastObject) {
        double[] problist = new double[this.privateParams.condbits];
        String conditions = "";
        this.getProbList(problist);

        for(int bit = 0; bit < this.privateParams.condbits; ++bit) {
            if (Math.random() < problist[bit]) {
                conditions = String.valueOf(String.valueOf(conditions)).concat(String.valueOf(String.valueOf(String.valueOf((int)(Math.random() * (double)2)))));
                fcastObject.incrSpecificity();
                fcastObject.updateSpecfactor();
            } else {
                conditions = String.valueOf(String.valueOf(conditions)).concat("2");
            }
        }

        fcastObject.conditions = conditions;
    }

    void prepareForTrading() {
        double forecastvar = 0.0D;
        new Forecast(this.privateParams.condbits);
        this.currentTime = this.getCurrentTime();
        if (this.currentTime >= this.privateParams.firstgatime && Math.random() < this.privateParams.gaprob) {
            AsmModel.localasm.setStatus("正在执行遗传算法");
            this.performGA();
            this.activeList.removeAllElements();
        }

        this.lforecast = this.forecast;
        String myworld = this.collectWorldData();
        this.updateActiveList(myworld);
        double maxstrength = -1.0E50D;
        Forecast bestForecast = null;
        int nactive = 0;
        int mincount = this.privateParams.mincount;
        int size = this.activeList.size();

        Forecast aForecast;
        for(int i = 0; i < size; ++i) {
            aForecast = (Forecast)this.activeList.elementAt(i);
            if (i == 0 && bestForecast == null) {
                bestForecast = aForecast;
            }

            aForecast.lastactive = this.currentTime;
            if (aForecast.incrCount() >= mincount) {
                double strength = aForecast.strength;
                ++nactive;
                if (strength > maxstrength || strength < -1.0E50D && maxstrength == -1.0E50D) {
                    maxstrength = strength;
                    bestForecast = aForecast;
                }
            }
        }

        double addvar;
        if (nactive >= 1) {
            this.pdcoeff = bestForecast.a;
            this.offset = bestForecast.b * this.dividend + bestForecast.c;
            if (this.privateParams.individual == 1) {
                forecastvar = bestForecast.variance;
            } else {
                forecastvar = this.variance;
            }
        } else {
            double countsum = 0.0D;
            this.pdcoeff = 0.0D;
            addvar = 0.0D;
            double offset1 = 0.0D;
            this.offset = 0.0D;
            mincount = this.privateParams.mincount;
            size = this.fcastList.size();

            for(int i = 0; i < size; ++i) {
                aForecast = (Forecast)this.fcastList.elementAt(i);
                if (aForecast.count >= 0) {
                    double weight = aForecast.strength;
                    countsum += weight;
                    this.offset += aForecast.b * this.dividend + aForecast.c * weight;
                    this.pdcoeff += aForecast.a * weight;
                    offset1 += aForecast.b * this.dividend + aForecast.c;
                    addvar += aForecast.a;
                }

                forecastvar = this.variance;
            }

            if (countsum > 0.0D) {
                this.offset /= countsum;
                this.pdcoeff /= countsum;
            } else {
                countsum = (double)size;
                this.offset = 0.0D;
                this.pdcoeff = 0.0D;
            }
        }

        addvar = this.privateParams.addvar;
        this.divisor = this.privateParams.lambda * forecastvar + addvar;
    }

    String collectWorldData() {
        String myRealWorld = null;
        String world = "";
        int nworldbits = this.worldForAgent.getNumWorldBits();
        myRealWorld = this.worldForAgent.getRealWorld();
        return myRealWorld;
    }

    void updateActiveList(String worldvalues) {
        this.copyList(this.activeList, this.oldActiveList);
        this.activeList.removeAllElements();
        int size = this.oldActiveList.size();

        Forecast aForecast;
        int i;
        for(i = 0; i < size; ++i) {
            aForecast = (Forecast)this.oldActiveList.elementAt(i);
            aForecast.lforecast = aForecast.forecast;
        }

        size = this.fcastList.size();

        for(i = 0; i < size; ++i) {
            aForecast = (Forecast)this.fcastList.elementAt(i);
            boolean tmp = true;

            for(int j = 0; j < aForecast.condbits; ++j) {
                int dumybits = World.NWORLDBITS - aForecast.condbits;
                char c1 = aForecast.conditions.charAt(j);
                char c2 = worldvalues.charAt(j + dumybits);
                if (c1 != '2' && c2 != c1) {
                    tmp = false;
                }
            }

            if (tmp) {
                this.activeList.addElement(aForecast);
            }
        }

    }

    double getDemandAndSlope(double[] slope, double trialprice) {
        this.forecast = (trialprice + this.dividend) * this.pdcoeff + this.offset;
        if (this.forecast >= 0.0D) {
            this.demand = -((trialprice * this.intratep1 - this.forecast) / this.divisor + this.position);
            slope[0] = (this.pdcoeff - this.intratep1) / this.divisor;
        } else {
            this.forecast = 0.0D;
            this.demand = -(trialprice * this.intratep1 / this.divisor + this.position);
            slope[0] = -this.intratep1 / this.divisor;
        }

        if (this.demand > this.privateParams.maxbid) {
            this.demand = this.privateParams.maxbid;
            slope[0] = 0.0D;
        } else if (this.demand < -this.privateParams.maxbid) {
            this.demand = -this.privateParams.maxbid;
            slope[0] = 0.0D;
        }

        this.constrainDemand(slope, trialprice);
        return this.demand;
    }

    void updatePerformance() {
        double tauv = this.privateParams.tauv;
        double a = 1.0D / tauv;
        double b = 1.0D - a;
        double av = 0.7D;
        double bv = 1.0D - av;
        if (tauv == (double)100000) {
            a = 0.0D;
            b = 1.0D;
            av = 0.0D;
            bv = 1.0D;
        }

        double maxdev = this.privateParams.maxdev;
        double maxprice = this.local.asmModelParams.maxprice;
        this.getPriceFromWorld();
        double ftarget = this.price + this.dividend;
        double deviation;
        this.realDeviation = deviation = ftarget - this.lforecast;
        if (Math.abs(deviation) > maxdev) {
            deviation = maxdev;
        }

        this.global_mean = b * this.global_mean + a * ftarget;
        this.currentTime = this.getCurrentTime();
        if (this.currentTime < 1) {
            this.variance = this.privateParams.initvar;
        } else {
            this.variance = bv * this.variance + av * deviation * deviation * maxdev * maxdev / (maxprice * maxprice);
        }

        int size = this.activeList.size();

        Forecast aForecast;
        int i;
        for(i = 0; i < size; ++i) {
            aForecast = (Forecast)this.activeList.elementAt(i);
            aForecast.updateForecastPrice(this.price, this.dividend);
        }

        if (this.currentTime > 0) {
            size = this.oldActiveList.size();

            for(i = 0; i < size; ++i) {
                aForecast = (Forecast)this.oldActiveList.elementAt(i);
                double lastForecast = aForecast.lforecast;
                deviation = (ftarget - lastForecast) * (ftarget - lastForecast) * maxdev * maxdev / (maxprice * maxprice);
                if (deviation > maxdev) {
                    deviation = maxdev;
                }

                if (aForecast.c > tauv) {
                    aForecast.variance = b * aForecast.variance + a * deviation;
                } else {
                    double c = 1.0D / (1.0D + (double)aForecast.count);
                    aForecast.variance = (1.0D - c) * aForecast.variance + c * deviation;
                }

                aForecast.strength = this.privateParams.maxdev - aForecast.variance + aForecast.specfactor;
            }
        }

    }

    double getDeviation() {
        return Math.abs(this.realDeviation);
    }

    int nbits() {
        return this.privateParams.condbits;
    }

    int nrules() {
        return this.privateParams.numfcasts;
    }

    int lastgatime() {
        return this.lastgatime;
    }

    void performGA() {
        double madv = 0.0D;
        double meanv = 0.0D;
        Vector newList = new Vector();
        Vector rejectList = new Vector();
        int[] rejectIndex = new int[this.privateParams.npool + 1];
        ++this.gacount;
        this.currentTime = this.getCurrentTime();
        this.lastgatime = this.currentTime;
        this.MakePool(rejectList, rejectIndex, this.fcastList);
        AsmModel.localasm.setStatus("正在执行遗传算法：计算平均值");
        double sumc = 0.0D;
        double avc = 0.0D;
        double avb = 0.0D;
        double ava = 0.0D;
        double avstrength = 0.0D;
        minstrength = 1.0E20D;

        int f;
        Forecast aForecast;
        double varvalue;
        for(f = 0; f < this.privateParams.numfcasts; ++f) {
            aForecast = (Forecast)this.fcastList.elementAt(f);
            varvalue = 0.0D;
            varvalue = aForecast.variance;
            meanv += varvalue;
            if (aForecast.count >= 0) {
                if (varvalue != (double)0) {
                    avstrength += aForecast.strength;
                    sumc += 1.0D / varvalue;
                    ava += aForecast.a / varvalue;
                    avb += aForecast.b / varvalue;
                    avc += aForecast.c / varvalue;
                }

                if (aForecast.strength < minstrength) {
                    minstrength = aForecast.strength;
                }
            }
        }

        meanv /= (double)this.privateParams.numfcasts;

        for(f = 0; f < this.privateParams.numfcasts; ++f) {
            aForecast = (Forecast)this.fcastList.elementAt(f);
            madv += Math.abs(aForecast.variance - meanv);
        }

        madv /= (double)this.privateParams.numfcasts;
        avstrength /= (double)this.privateParams.numfcasts;
        AsmModel.localasm.setStatus("正在执行遗传算法：正在进行遗传操作");

        Forecast parent1;
        for(int new1 = 0; new1 < this.privateParams.nnew; ++new1) {
            boolean changed = false;

            do {
                double altvarvalue = 9.99999999E8D;
                new Forecast(this.privateParams.condbits);
                Forecast aNewForecast = this.createNewForecast();
                aNewForecast.updateSpecfactor();
                aNewForecast.strength = avstrength;
                aNewForecast.lastactive = this.currentTime;
                varvalue = this.privateParams.maxdev - avstrength + aNewForecast.specfactor;
                aNewForecast.variance = varvalue;
                Forecast temp1 = (Forecast)this.fcastList.elementAt(0);
                altvarvalue = temp1.variance - madv;
                if (varvalue < altvarvalue) {
                    aNewForecast.variance = altvarvalue;
                    aNewForecast.strength = this.privateParams.maxdev - altvarvalue + aNewForecast.specfactor;
                }

                aNewForecast.lastactive = this.currentTime;

                do {
                    parent1 = this.Tournament(this.fcastList);
                } while(parent1 == null);

                if (Math.random() >= this.privateParams.pcrossover) {
                    aNewForecast = this.CopyRule(parent1);
                    changed = this.Mutate(aNewForecast, changed);
                } else {
                    while(true) {
                        Forecast parent2;
                        do {
                            parent2 = this.Tournament(this.fcastList);
                        } while(parent2 == parent1);

                        if (parent2 != null) {
                            aNewForecast = this.Crossover(aNewForecast, parent1, parent2);
                            changed = true;
                            break;
                        }
                    }
                }

                newList.addElement(aNewForecast);
            } while(!changed);
        }

        AsmModel.localasm.setStatus("正在执行遗传算法：用新规则淘汰旧规则");
        this.TransferFcastsFrom(newList, this.fcastList, rejectList, rejectIndex);
        AsmModel.localasm.setStatus("正在执行遗传算法：强迫没有被激活的规则产生多样性");
        this.Generalize(this.fcastList, avstrength);
        AsmModel.localasm.setStatus("正在执行遗传算法：重新计算平均值");
        int specificity = 0;

        for(f = 0; f < this.privateParams.numfcasts; ++f) {
            parent1 = (Forecast)this.fcastList.elementAt(f);
            specificity += parent1.specificity;
        }

        this.avspecificity = (double)specificity / (double)this.privateParams.numfcasts;
        AsmModel.localasm.setStatus("执行遗传算法结束");
        newList.removeAllElements();
        rejectList.removeAllElements();
    }

    Forecast CopyRule(Forecast from) {
        Forecast to = new Forecast(this.privateParams.condbits);
        to.forecast = from.forecast;
        to.lforecast = from.lforecast;
        to.variance = from.variance;
        to.strength = from.strength;
        to.a = from.a;
        to.b = from.b;
        to.c = from.c;
        to.specfactor = from.specfactor;
        to.lastactive = from.lastactive;
        to.specificity = from.specificity;
        to.conditions = from.conditions;
        to.count = from.count;
        if (from.count == 0) {
            to.strength = minstrength;
        }

        return to;
    }

    void MakePool(Vector rejects, int[] indexes, Vector list) {
        int j = 0;
        new Forecast(this.privateParams.condbits);
        int top = -1;

        int i;
        Forecast aForecast;
        Forecast aReject;
        for(i = 0; i < this.privateParams.npool; ++i) {
            aForecast = (Forecast)list.elementAt(i);

            for(j = top; j >= 0; --j) {
                aReject = (Forecast)rejects.elementAt(j);
                int k = indexes[j];
                if (aReject == null || aForecast.strength >= aReject.strength) {
                    break;
                }

                if (rejects.size() > j + 1) {
                    rejects.removeElementAt(j + 1);
                }

                rejects.insertElementAt(aReject, j + 1);
                indexes[j + 1] = k;
            }

            if (rejects.size() > j + 1) {
                rejects.removeElementAt(j + 1);
            }

            rejects.insertElementAt(aForecast, j + 1);
            indexes[j + 1] = i;
            ++top;
        }

        for(i = i; i < this.privateParams.numfcasts; ++i) {
            aForecast = (Forecast)list.elementAt(i);
            Forecast temp1 = (Forecast)rejects.elementAt(top);
            if (aForecast.strength < temp1.strength) {
                for(j = top - 1; j >= 0; --j) {
                    aReject = (Forecast)rejects.elementAt(j);
                    int k = indexes[j];
                    if (aReject == null || aForecast.strength >= aReject.strength) {
                        break;
                    }

                    if (rejects.size() > j + 1) {
                        rejects.removeElementAt(j + 1);
                    }

                    indexes[j + 1] = k;
                    rejects.insertElementAt(aReject, j + 1);
                }
            }

            if (rejects.size() > j + 1) {
                rejects.removeElementAt(j + 1);
            }

            indexes[j + 1] = i;
            rejects.insertElementAt(aForecast, j + 1);
        }

    }

    Forecast Tournament(Vector list) {
        int numfcasts = list.size();
        Forecast candidate1 = (Forecast)list.elementAt((int)(Math.random() * (double)numfcasts));

        Forecast candidate2;
        do {
            candidate2 = (Forecast)list.elementAt((int)(Math.random() * (double)numfcasts));
        } while(candidate2 == candidate1);

        return candidate1.strength > candidate2.strength ? candidate1 : candidate2;
    }

    boolean Mutate(Forecast new1, boolean changed) {
        boolean bitchanged = false;
        if (this.privateParams.pmutation > (double)0) {
            for(int bit = 0; bit < this.privateParams.condbits; ++bit) {
                if (Math.random() < this.privateParams.pmutation) {
                    if (Integer.parseInt(new1.getConditionsbit(bit)) < 2) {
                        if ((int)(Math.random() * (double)3) > 1) {
                            new1.maskConditionsbit(bit);
                            new1.decrSpecificity();
                        } else {
                            new1.switchConditionsbit(bit);
                            changed = true;
                            bitchanged = true;
                        }
                    } else if ((int)(Math.random() * (double)3) > 0) {
                        new1.setConditionsbit(bit, String.valueOf((int)(Math.random() * (double)2)));
                        new1.incrSpecificity();
                        changed = true;
                        bitchanged = true;
                    }
                }
            }
        }

        double choice = Math.random();
        double temp;
        if (choice < this.privateParams.plong) {
            new1.a = this.privateParams.a_min + this.privateParams.a_range * Math.random();
            changed = true;
        } else if (choice < this.privateParams.plong + this.privateParams.pshort) {
            temp = new1.a + this.privateParams.a_range * this.privateParams.nhood * (Math.random() * (double)2 - (double)1);
            if (temp > this.privateParams.a_max) {
                new1.a = this.privateParams.a_max;
            } else if (temp < this.privateParams.a_min) {
                new1.a = this.privateParams.a_min;
            } else {
                new1.a = temp;
            }

            changed = true;
        }

        choice = Math.random();
        if (choice < this.privateParams.plong) {
            new1.b = this.privateParams.b_min + this.privateParams.b_range * Math.random();
            changed = true;
        } else if (choice < this.privateParams.plong + this.privateParams.pshort) {
            temp = new1.b + this.privateParams.b_range * this.privateParams.nhood * (Math.random() * (double)2 - (double)1);
            if (temp > this.privateParams.b_max) {
                new1.b = this.privateParams.b_max;
            } else if (temp < this.privateParams.b_min) {
                new1.b = this.privateParams.b_min;
            } else {
                new1.b = temp;
            }

            changed = true;
        }

        choice = Math.random();
        if (choice < this.privateParams.plong) {
            new1.c = this.privateParams.c_min + this.privateParams.c_range * Math.random();
            changed = true;
        } else if (choice < this.privateParams.plong + this.privateParams.pshort) {
            temp = new1.c + this.privateParams.c_range * this.privateParams.nhood * (Math.random() * (double)2 - (double)1);
            if (temp > this.privateParams.c_max) {
                new1.c = this.privateParams.c_max;
            } else if (temp < this.privateParams.c_min) {
                new1.c = this.privateParams.c_min;
            } else {
                new1.c = temp;
            }

            changed = true;
        }

        new1.count = 0;
        if (changed) {
            new1.updateSpecfactor();
        }

        return changed;
    }

    Forecast Crossover(Forecast newForecast, Forecast parent1, Forecast parent2) {
        newForecast.specificity = 0;

        int bit;
        String newcond;
        for(bit = 0; bit < this.privateParams.condbits; ++bit) {
            if ((int)(Math.random() * (double)2) == 0) {
                newcond = parent1.getConditionsbit(bit);
                newForecast.setConditionsbit(bit, newcond);
                if (Integer.parseInt(newcond) < 2) {
                    newForecast.incrSpecificity();
                }
            } else {
                newcond = parent2.getConditionsbit(bit);
                newForecast.setConditionsbit(bit, newcond);
                if (Integer.parseInt(newcond) < 2) {
                    newForecast.incrSpecificity();
                }
            }
        }

        double choice = Math.random();
        if (choice < this.privateParams.plinear) {
            double weight1;
            if (parent1.strength + parent2.strength != (double)0) {
                weight1 = parent1.strength / (parent1.strength + parent2.strength);
            } else {
                weight1 = 0.5D;
            }

            double weight2 = 1.0D - weight1;
            newForecast.a = weight1 * parent1.a + weight2 * parent2.a;
            newForecast.b = weight1 * parent1.b + weight2 * parent2.b;
            newForecast.c = weight1 * parent1.c + weight2 * parent2.c;
        } else if (choice < this.privateParams.plinear + this.privateParams.prandom) {
            if ((int)(Math.random() * (double)2) == 0) {
                newForecast.a = parent1.a;
            } else {
                newForecast.a = parent2.a;
            }

            if ((int)(Math.random() * (double)2) == 0) {
                newForecast.b = parent1.b;
            } else {
                newForecast.b = parent2.b;
            }

            if ((int)(Math.random() * (double)2) == 0) {
                newForecast.c = parent1.c;
            } else {
                newForecast.c = parent2.c;
            }
        } else if ((int)(Math.random() * (double)2) == 0) {
            newForecast.a = parent1.a;
            newForecast.b = parent1.b;
            newForecast.c = parent1.c;
        } else {
            newForecast.a = parent2.a;
            newForecast.b = parent2.b;
            newForecast.c = parent2.c;
        }

        int specificity = 0;
        newForecast.count = 0;
        newForecast.updateSpecfactor();
        newForecast.strength = 0.5D * (parent1.strength + parent2.strength);
        newcond = newForecast.conditions;

        for(bit = 0; bit < this.privateParams.condbits; ++bit) {
            if (newcond.charAt(bit) != '2') {
                ++specificity;
            }
        }

        return newForecast;
    }

    void TransferFcastsFrom(Vector newlist, Vector fcastlist, Vector rejects, int[] indexes) {
        int size = newlist.size();

        for(int i = 0; i < size; ++i) {
            Forecast aForecast = (Forecast)newlist.elementAt(i);
            int k = this.GetMort(aForecast, rejects, indexes);
            fcastlist.removeElementAt(k);
            fcastlist.addElement(aForecast);
        }

    }

    int GetMort(Forecast new1, Vector rejects, int[] indexes) {
        boolean bitmax = false;
        int numrejects = this.privateParams.npool;

        int r1;
        do {
            r1 = (int)(Math.random() * (double)numrejects);
        } while(rejects.elementAt(r1) == null);

        int r2;
        do {
            do {
                r2 = (int)(Math.random() * (double)numrejects);
            } while(r1 == r2);
        } while(rejects.elementAt(r2) == null);

        Forecast temp3 = (Forecast)rejects.elementAt(r1);
        Forecast temp4 = (Forecast)rejects.elementAt(r2);
        String cond1 = temp3.conditions;
        String cond2 = temp4.conditions;
        String newcond = new1.conditions;
        int different1 = 0;
        int different2 = 0;
        bitmax = true;

        for(int bit = 0; bit < this.privateParams.condbits; ++bit) {
            if (cond1.charAt(bit) != newcond.charAt(bit)) {
                ++different1;
            }

            if (cond2.charAt(bit) != newcond.charAt(bit)) {
                ++different2;
            }
        }

        int result;
        if (different1 < different2) {
            result = indexes[r1];
        } else {
            result = indexes[r2];
        }

        return result;
    }

    void Generalize(Vector list, double avgstrength) {
        this.currentTime = this.getCurrentTime();

        for(int f = 0; f < this.privateParams.numfcasts; ++f) {
            Forecast aForecast = (Forecast)list.elementAt(f);
            if (this.currentTime - aForecast.lastactive > this.privateParams.longtime) {
                boolean changed = false;
                int j = (int)Math.ceil((double)aForecast.specificity * this.privateParams.genfrac);

                while(j > 0 && aForecast.specificity > 0) {
                    int bit = (int)(Math.random() * (double)this.privateParams.condbits);
                    if (Integer.parseInt(aForecast.getConditionsbit(bit)) < 2) {
                        aForecast.maskConditionsbit(bit);
                        aForecast.decrSpecificity();
                        changed = true;
                        --j;
                    }
                }

                if (changed) {
                    aForecast.count = 0;
                    aForecast.lastactive = this.currentTime;
                    aForecast.updateSpecfactor();
                    double varvalue = this.privateParams.maxdev - avgstrength + aForecast.specfactor;
                    if (varvalue > (double)0) {
                        aForecast.variance = varvalue;
                    }

                    aForecast.strength = avgstrength;
                }
            }
        }

    }

    void copyList(Vector list, Vector outputList) {
        outputList.removeAllElements();
        int size = list.size();

        for(int i = 0; i < size; ++i) {
            Forecast aforecast = (Forecast)list.elementAt(i);
            outputList.addElement(aforecast);
        }

    }

    void GetRule(Vector list, String[] out, int index) {
        Forecast aForecast = (Forecast)list.elementAt(index);
        out[0] = Float.toString((float)aForecast.forecast);
        out[5] = Float.toString((float)aForecast.variance);
        out[1] = Float.toString((float)aForecast.strength);
        out[2] = Float.toString((float)aForecast.a);
        out[3] = Float.toString((float)aForecast.b);
        out[4] = Float.toString((float)aForecast.c);
        out[7] = aForecast.conditions;
        out[6] = Integer.toString(aForecast.count);
    }

    double GetStrength(Vector list, int index) {
        Forecast aForecast = (Forecast)list.elementAt(index);
        return aForecast.strength;
    }

    void getBitList(int[] bits) {
        int condbits = this.privateParams.condbits;

        for(int i = 0; i < condbits; bits[i] = i++) {
        }

    }

    void getProbList(double[] ProbList) {
        int condbits = this.privateParams.condbits;
        double tmp = this.privateParams.newfcastspec;

        for(int i = 0; i < condbits; ++i) {
            ProbList[i] = Math.random() * tmp;
        }

    }

    public Agent(AsmModel lcl) {
        this.local = lcl;
        this.fcastList = new Vector();
        this.activeList = new Vector();
        this.oldActiveList = new Vector();
        this.History = new Vector();
    }

    int getCurrentTime() {
        return this.local.modelTime;
    }

    public void RecordHistory(int currentTime) {
        AgentVariants agv = new AgentVariants();
        agv.cash = this.cash;
        agv.avspecificity = this.avspecificity;
        agv.currentTime = currentTime;
        agv.demand = this.demand;
        agv.divisor = this.divisor;
        agv.forecast = this.forecast;
        agv.gacount = this.gacount;
        agv.global_mean = this.global_mean;
        agv.offset = this.offset;
        agv.pdcoeff = this.pdcoeff;
        agv.position = this.position;
        agv.profit = this.profit;
        agv.realDeviation = this.realDeviation;
        agv.variance = this.variance;
        agv.wealth = this.wealth;
        this.History.addElement(agv);
        if (this.History.size() > WorldVariants.cycleMax) {
            this.History.removeElementAt(0);
        }

    }
}
