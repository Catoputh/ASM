//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package asm;

import java.awt.Button;
import java.awt.CheckboxGroup;
import java.awt.Choice;
import java.awt.Event;
import java.awt.Frame;
import java.awt.Label;
import java.awt.LayoutManager;
import java.awt.List;
import java.awt.Rectangle;
import java.awt.SystemColor;
import java.awt.TextArea;
import java.awt.TextField;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Vector;

public class RuleView extends Frame implements Runnable {
    Thread runner1;
    List lstRules = new List();
    AsmModel local;
    Label label1 = new Label();
    Choice choiceAgent = new Choice();
    Button btnRefresh = new Button();
    TextArea txtShow = new TextArea();
    int nSelRule;
    int[] index;
    String[] area;
    Label label2 = new Label();
    CheckboxGroup checkboxGroup1 = new CheckboxGroup();
    Choice choiceMethod = new Choice();
    Label label3 = new Label();
    TextField txtWorld = new TextField();
    Label label4 = new Label();
    TextField txtPrice = new TextField();
    Label label5 = new Label();
    TextField txtDividend = new TextField();

    public RuleView(AsmModel loc) {
        super("查看规则");
        this.local = loc;

        try {
            this.jbInit();
        } catch (Exception var3) {
            var3.printStackTrace();
        }

    }

    private void jbInit() throws Exception {
        this.setLayout((LayoutManager)null);
        this.lstRules.setBounds(new Rectangle(11, 27, 769, 283));
        this.lstRules.addMouseListener(new MouseAdapter((RuleView)this) {

            private final Object this$0;

            {
                this.this$0 = this$0;
            }

            public void mouseClicked(MouseEvent e) {
                this.this$0.lstRules_mouseClicked(e);
            }
        });
        this.addWindowListener(new WindowAdapter((RuleView)this) {
            {
                this.this$0 = this$0;
            }

            public void windowClosing(WindowEvent e) {
                this.this$0.this_windowClosing(e);
            }
        });
        this.label1.setText("选择Agent：");
        this.label1.setBounds(new Rectangle(6, 446, 70, 16));
        this.choiceAgent.setBounds(new Rectangle(76, 446, 70, 17));

        for(int i = 0; i < this.local.agentList.size(); ++i) {
            this.choiceAgent.addItem(Integer.toString(i));
        }

        this.addWindowListener(new WindowAdapter((RuleView)this) {
            {
                this.this$0 = this$0;
            }

            public void windowOpened(WindowEvent e) {
                this.this$0.this_windowOpened(e);
            }
        });
        this.btnRefresh.setLabel("刷新");
        this.btnRefresh.setBounds(new Rectangle(177, 443, 98, 20));
        this.txtShow.setBounds(new Rectangle(9, 335, 600, 104));
        this.setBackground(SystemColor.inactiveCaptionBorder);
        this.label2.setText("查看：");
        this.label2.setBounds(new Rectangle(11, 315, 49, 16));
        this.choiceMethod.setBounds(new Rectangle(65, 315, 103, 16));
        this.choiceMethod.addItem("全部规则");
        this.choiceMethod.addItem("激活的规则");
        this.label3.setText("当前世界的编码：");
        this.label3.setBounds(new Rectangle(212, 313, 99, 16));
        this.txtWorld.setBounds(new Rectangle(314, 315, 465, 18));
        this.label4.setText("价格：");
        this.label4.setBounds(new Rectangle(618, 356, 43, 16));
        this.txtPrice.setBounds(new Rectangle(660, 356, 112, 20));
        this.label5.setText("股息：");
        this.label5.setBounds(new Rectangle(618, 399, 43, 20));
        this.txtDividend.setBounds(new Rectangle(660, 401, 111, 19));
        this.add(this.lstRules, (Object)null);
        this.add(this.label1, (Object)null);
        this.add(this.choiceAgent, (Object)null);
        this.add(this.btnRefresh, (Object)null);
        this.add(this.txtShow, (Object)null);
        this.add(this.label2, (Object)null);
        this.add(this.choiceMethod, (Object)null);
        this.add(this.label3, (Object)null);
        this.add(this.txtWorld, (Object)null);
        this.add(this.label4, (Object)null);
        this.add(this.label5, (Object)null);
        this.add(this.txtPrice, (Object)null);
        this.add(this.txtDividend, (Object)null);
    }

    public void updateWorld() {
        String world = this.local.world.getRealWorld();
        this.txtWorld.setText(world);
        this.txtPrice.setText(String.valueOf(this.local.world.getPrice()));
        this.txtDividend.setText(String.valueOf(this.local.world.getDividend()));
        Vector agList = this.local.agentList;
        this.lstRules.removeAll();
        String[] output = new String[8];
        Agent ag = (Agent)agList.elementAt(this.choiceAgent.getSelectedIndex());
        Vector activeRules;
        if (this.choiceMethod.getSelectedIndex() == 0) {
            activeRules = ag.fcastList;
        } else {
            activeRules = ag.activeList;
        }

        this.index = new int[activeRules.size()];
        this.area = new String[activeRules.size()];

        int size;
        for(size = 0; size < activeRules.size(); this.index[size] = size++) {
        }

        size = activeRules.size();

        int i;
        for(int m = 0; m < size - 1; ++m) {
            for(int n = m + 1; n < size; ++n) {
                if (ag.GetStrength(activeRules, this.index[m]) < ag.GetStrength(activeRules, this.index[n])) {
                    i = this.index[m];
                    this.index[m] = this.index[n];
                    this.index[n] = i;
                }
            }
        }

        String space = "____";
        String out = String.valueOf(String.valueOf((new StringBuffer("编号")).append(space).append("预测值").append(space).append("____强度").append(space).append(space).append("a").append(space).append(space).append("b").append(space).append(space).append(space).append("c").append(space).append(space).append("方差").append(space).append("次数")));
        space = "\t";
        this.lstRules.add(out);

        for(i = 0; i < activeRules.size(); ++i) {
            out = "";
            out = Integer.toString(this.index[i]);
            int s = 4 - out.length();

            int j;
            for(j = 1; j < s; ++j) {
                out = String.valueOf(String.valueOf(out)).concat("_");
            }

            out = String.valueOf(String.valueOf(out)).concat(String.valueOf(String.valueOf(space)));
            ag.GetRule(activeRules, output, this.index[i]);

            for(j = 0; j < 7; ++j) {
                for(int k = 1; k <= 10; ++k) {
                    if (k <= output[j].length()) {
                        out = String.valueOf(String.valueOf(out)).concat(String.valueOf(String.valueOf(output[j].substring(k - 1, k))));
                    } else {
                        out = String.valueOf(String.valueOf(out)).concat("_");
                    }
                }

                out = String.valueOf(String.valueOf(out)).concat(String.valueOf(String.valueOf(space)));
            }

            this.area[i] = output[j];
            this.lstRules.add(out);
        }

    }

    public void stop() {
        if (this.runner1 != null) {
            this.runner1.stop();
            this.runner1 = null;
        }

    }

    public void run() {
        while(true) {
            this.updateWorld();

            try {
                Thread.sleep(200000L);
            } catch (InterruptedException var2) {
            }
        }
    }

    void this_windowClosing(WindowEvent e) {
        this.hide();
        this.dispose();
    }

    void this_windowOpened(WindowEvent e) {
        if (this.runner1 == null) {
            this.runner1 = new Thread(this);
            this.runner1.start();
        }

    }

    public boolean action(Event evt, Object o) {
        if (evt.target == this.btnRefresh) {
            this.updateWorld();
            return true;
        } else if (evt.target == this.choiceAgent) {
            this.updateWorld();
            return true;
        } else if (evt.target == this.lstRules) {
            this.nSelRule = this.lstRules.getSelectedIndex();
            this.txtShow.setText(this.area[this.nSelRule]);
            return true;
        } else if (evt.target == this.choiceMethod) {
            this.updateWorld();
            return true;
        } else {
            return false;
        }
    }

    void lstRules_mouseClicked(MouseEvent e) {
        this.nSelRule = this.lstRules.getSelectedIndex();
        if (this.nSelRule != 0) {
            --this.nSelRule;
            String condition = this.area[this.nSelRule];
            String explain = "";

            for(int i = 3; i < condition.length(); ++i) {
                String tmp = condition.substring(i, i + 1);
                if (tmp.equals("1")) {
                    explain = String.valueOf(String.valueOf(explain)).concat(String.valueOf(String.valueOf(String.valueOf(String.valueOf(this.local.world.descriptionOfBit(i))).concat(" and\n"))));
                } else if (tmp.equals("0")) {
                    explain = String.valueOf(String.valueOf(explain)).concat(String.valueOf(String.valueOf(String.valueOf(String.valueOf((new StringBuffer("not ")).append(this.local.world.descriptionOfBit(i)).append(" and\n"))))));
                }
            }

            condition = condition.replace('2', '#');
            String result = String.valueOf(String.valueOf((new StringBuffer("条件编码:")).append(condition).append("\n")));
            result = String.valueOf(String.valueOf(result)).concat("解释：\n");
            result = String.valueOf(String.valueOf(result)).concat(String.valueOf(String.valueOf("if\n".concat(String.valueOf(String.valueOf(explain))))));
            this.txtShow.setText(result);
        }
    }
}
