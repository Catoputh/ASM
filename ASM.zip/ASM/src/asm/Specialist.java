//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package asm;

import java.util.Vector;

class Specialist {
    public double maxprice;
    public double minprice;
    public double eta;
    public double minexcess;
    public double rea;
    public double reb;
    public double bidfrac;
    public double offerfrac;
    public int maxiterations;
    public double volume;
    public double taupdecay;
    public double taupnew;
    int sptype;

    Specialist() {
    }

    void setTaup(double aTaup) {
        this.taupnew = -Math.exp(-1.0D / aTaup);
        this.taupdecay = 1.0D - this.taupnew;
    }

    void setSPtype(int i) {
        if (i != 0 && i != 1 && i != 2 && i != 3) {
            i = 1;
        }

        this.sptype = i;
    }

    double performTrading(Vector agentList, World worldForSpec) {
        double[] slope = new double[1];
        double slopetotal = 0.0D;
        double trialprice = 0.0D;
        double offertotal = 0.0D;
        double bidtotal = 0.0D;
        this.volume = 0.0D;
        double dividend = worldForSpec.getDividend();
        int mcount = 0;

        for(boolean done = false; mcount < this.maxiterations && !done; ++mcount) {
            int size;
            switch(this.sptype) {
                case 0:
                    trialprice = this.rea * dividend + this.reb;
                    done = true;
                    break;
                case 1:
                    if (mcount == 0) {
                        trialprice = worldForSpec.getPrice();
                    } else {
                        double imbalance = bidtotal - offertotal;
                        if (imbalance <= this.minexcess && imbalance >= -this.minexcess) {
                            done = true;
                            continue;
                        }

                        if (slopetotal != (double)0) {
                            trialprice += imbalance / ((double)10 + slopetotal);
                        } else {
                            trialprice *= (double)1 + this.eta * imbalance;
                        }
                    }
                    break;
                case 2:
                    if (mcount == 0) {
                        trialprice = worldForSpec.getPrice();
                    } else {
                        trialprice = worldForSpec.getPrice() * (1.0D + this.eta * (bidtotal - offertotal));
                        done = true;
                    }
                    break;
                case 3:
                    size = agentList.size();
                    double sigmaa = 0.0D;
                    double sigmab = 0.0D;
                    double sigmac = 0.0D;

                    for(size = 0; size < size; ++size) {
                        Agent agent = (Agent)agentList.elementAt(size);
                        sigmac += (double)ASMParam.initholding;
                        sigmab += (agent.pdcoeff * dividend + agent.offset) / agent.divisor;
                        sigmaa += (agent.pdcoeff - agent.intratep1) / agent.divisor;
                    }

                    if (sigmaa != (double)0) {
                        trialprice = (sigmac - sigmab) / (sigmaa + (double)1);
                    }

                    done = true;
            }

            if (trialprice < this.minprice) {
                trialprice = this.minprice;
            }

            if (trialprice > this.maxprice) {
                trialprice = this.maxprice;
            }

            bidtotal = 0.0D;
            offertotal = 0.0D;
            slopetotal = 0.0D;
            size = agentList.size();

            for(int i = 0; i < size; ++i) {
                Agent agent = (Agent)agentList.elementAt(i);
                slope[0] = 0.0D;
                double demand = agent.getDemandAndSlope(slope, trialprice);
                slopetotal += slope[0];
                if (demand > 0.0D) {
                    bidtotal += demand;
                } else if (demand < 0.0D) {
                    offertotal -= demand;
                }
            }

            if (bidtotal > offertotal) {
                this.volume = offertotal;
            } else {
                this.volume = bidtotal;
            }

            if (bidtotal > 0.0D) {
                this.bidfrac = this.volume / bidtotal;
            } else {
                this.volume = 0.0D;
            }

            if (offertotal > 0.0D) {
                this.offerfrac = this.volume / offertotal;
            } else {
                this.offerfrac = 0.0D;
            }
        }

        return trialprice;
    }

    void completeTrades(Vector agentList, World worldForSpec) {
        double price = 0.0D;
        price = worldForSpec.getPrice();
        double profitperunit = worldForSpec.getProfitPerUnit();
        double bfp = this.bidfrac * price;
        double ofp = this.offerfrac * price;
        double tp = this.taupnew * profitperunit;
        int size = agentList.size();

        for(int i = 0; i < size; ++i) {
            Agent agent1 = (Agent)agentList.elementAt(i);
            agent1.profit = this.taupdecay * agent1.profit + tp * agent1.position;
            if (agent1.demand > 0.0D) {
                agent1.position += agent1.demand * this.bidfrac;
                agent1.cash -= agent1.demand * bfp;
            } else if (agent1.demand < 0.0D) {
                agent1.position += agent1.demand * this.offerfrac;
                agent1.cash -= agent1.demand * ofp;
            }
        }

    }
}
