//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package asm;

class Forecast {
    public double forecast;
    public double lforecast;
    public double variance;
    public double strength;
    public double a;
    public double b;
    public double c;
    public double specfactor;
    public double bitcost;
    public String conditions;
    public int lastactive;
    public int specificity;
    public int count;
    public int condbits;
    public int nnulls;

    public Forecast(int cond) {
        this.condbits = cond;
        if (this.condbits != 0) {
            this.forecast = 0.0D;
            this.count = 0;
            this.lastactive = 1;
            this.specificity = 0;
            this.variance = 9.99999999E8D;
            this.conditions = "";
            if (this.condbits <= 60) {
                this.conditions = "22222222222222222222222222222222222222222222222222222222222222";
            } else {
                for(int i = 0; i < this.condbits; ++i) {
                    this.conditions = String.valueOf(String.valueOf(this.conditions)).concat("2");
                }
            }

        }
    }

    void setConditions(String x) {
        this.conditions = x;
    }

    String getConditions() {
        return this.conditions;
    }

    void setConditionsbit(int bit, String x) {
        String temp1 = this.conditions.substring(0, bit);
        String temp2 = this.conditions.substring(bit + 1);
        this.conditions = String.valueOf(String.valueOf((new StringBuffer(String.valueOf(String.valueOf(temp1)))).append(x).append(temp2)));
    }

    String getConditionsbit(int bit) {
        return this.conditions.substring(bit, bit + 1);
    }

    void maskConditionsbit(int bit) {
        this.setConditionsbit(bit, "2");
    }

    void switchConditionsbit(int bit) {
        String s = this.getConditionsbit(bit);
        if (s == "0") {
            s = "1";
        } else if (s == "1") {
            s = "0";
        }

        this.setConditionsbit(bit, s);
    }

    void updateSpecfactor() {
        this.specfactor = (double)(this.condbits - this.nnulls - this.specificity) * this.bitcost;
    }

    void incrSpecificity() {
        ++this.specificity;
    }

    void decrSpecificity() {
        --this.specificity;
    }

    int incrCount() {
        return ++this.count;
    }

    double updateForecastPrice(double price, double dividend) {
        this.lforecast = this.forecast;
        this.forecast = this.a * (price + dividend) + this.b * dividend + this.c;
        return this.forecast;
    }

    void copyEverythingFrom(Forecast from) {
        this.forecast = from.forecast;
        this.lforecast = from.lforecast;
        this.variance = from.variance;
        this.strength = from.strength;
        this.a = from.a;
        this.b = from.b;
        this.c = from.c;
        this.specfactor = from.specfactor;
        this.lastactive = from.lastactive;
        this.specificity = from.specificity;
        this.count = from.count;
        this.conditions = from.conditions;
    }
}
