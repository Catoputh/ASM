//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package asm;

import java.awt.Frame;

public class AgentParam extends Frame {
    public int numfcasts = 100;
    public int condbits = 60;
    public int mincount = 1;
    public int gafrequency = 1000;
    public int firstgatime = 2;
    public int longtime;
    public int individual = 0;
    public double tauv = 50.0D;
    public double lambda = 0.9D;
    public double maxbid = 10.0D;
    public double bitprob;
    public double subrange = 1.0D;
    public double a_min = 0.0D;
    public double a_max = 4.0D;
    public double b_min = -10.0D;
    public double b_max = 10.0D;
    public double c_min = -1.0D;
    public double c_max = 5.0D;
    public double a_range;
    public double b_range;
    public double c_range;
    public double newfcastvar = 0.6D;
    public double newfcastspec = 0.4D;
    public double addvar = 10.0D;
    public double initvar = 1.0D;
    public double bitcost = 0.02D;
    public double maxdev;
    public double poolfrac;
    public double newfrac;
    public double pcrossover;
    public double plinear;
    public double prandom;
    public double pmutation;
    public double plong;
    public double pshort;
    public double nhood;
    public double genfrac;
    public double gaprob;
    public int npool;
    public int nnew;
    public int nnulls = 0;
    public int npoolmax;
    public int nnewmax;
    public int ncondmax;

    public AgentParam() {
        this.initvar = 50.0D;
        this.maxdev = 100.0D;
        this.pcrossover = 0.3D;
        this.pmutation = 0.01D;
        this.plong = 0.6D;
        this.pshort = 0.3D;
        this.plinear = 0.4D;
        this.prandom = 0.3D;
        this.longtime = 200;
        this.genfrac = 0.1D;
        this.nhood = 3.0D;
        this.poolfrac = 0.3D;
        this.newfrac = 0.2D;
        this.npoolmax = 10;
        this.nnewmax = 10;
        this.ncondmax = 10;
        this.reinit();
    }

    public void reinit() {
        this.a_range = this.a_max - this.a_min;
        this.b_range = this.b_max - this.b_min;
        this.c_range = this.c_max - this.c_min;
        this.gaprob = 1.0D / (double)this.gafrequency;
        if (1.0D + this.bitcost * (double)(this.condbits - this.nnulls) > 0.0D) {
            this.npool = (int)((double)this.numfcasts * this.poolfrac + 0.5D);
            this.nnew = (int)((double)this.numfcasts * this.newfrac + 0.5D);
            if (this.npool > this.npoolmax) {
                this.npoolmax = this.npool;
            }

            if (this.nnew > this.nnewmax) {
                this.nnewmax = this.nnew;
            }

        }
    }
}
