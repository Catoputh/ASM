//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package asm;

class Dividend {
    public double baseline;
    public double amplitude;
    public int period;
    public double mindividend;
    public double maxdividend;
    public double deviation;
    public double rho;
    public double gauss;
    public double dvdnd;

    Dividend() {
    }

    void initNormal() {
    }

    double setAmplitude(double theAmplitude) {
        this.amplitude = theAmplitude;
        if (this.amplitude < 0.0D) {
            this.amplitude = 0.0D;
        }

        if (this.amplitude > 1.0D) {
            this.amplitude = 1.0D;
        }

        this.amplitude = 1.0E-4D * (double)((int)(10000.0D * this.amplitude));
        return this.amplitude;
    }

    int setPeriod(int thePeriod) {
        this.period = thePeriod;
        if (this.period < 2) {
            this.period = 2;
        }

        return this.period;
    }

    void setDerivedParams() {
        this.deviation = this.baseline * this.amplitude;
        this.rho = Math.exp(-1.0D / (double)this.period);
        this.rho = 1.0E-4D * (double)((int)(10000.0D * this.rho));
        this.gauss = this.deviation * Math.sqrt(1.0D - this.rho * this.rho);
        this.dvdnd = this.baseline + this.gauss * this.normal(1000);
    }

    double dividend() {
        this.dvdnd = this.baseline + this.rho * (this.dvdnd - this.baseline) + this.gauss * this.normal(1000);
        if (this.dvdnd < this.mindividend) {
            this.dvdnd = this.mindividend;
        }

        if (this.dvdnd > this.maxdividend) {
            this.dvdnd = this.maxdividend;
        }

        return this.dvdnd;
    }

    double normal(int n) {
        double s = 0.0D;

        for(int i = 0; i < n; ++i) {
            s += Math.random();
        }

        return Math.sqrt(12.0D / (double)n) * (s - (double)(n / 2));
    }
}
