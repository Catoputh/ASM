//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package asm;

import java.awt.Choice;
import java.awt.Color;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Label;
import java.awt.LayoutManager;
import java.awt.Panel;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.lang.reflect.Parameter;
import java.util.Vector;

public class CurveShow extends Frame implements Runnable {
    Panel view = new Panel();
    Thread runner1;
    Graphics gra;
    int cycles = 100;
    int cyclemax;
    int originx = 40;
    int originy = 20;
    int type;
    public int nAgentIndex = 0;
    AsmModel local;
    Choice choicelen = new Choice();
    Label label1 = new Label();
    Label label2 = new Label();
    Choice choiceItem1 = new Choice();
    Label label3 = new Label();
    Choice choiceItem2 = new Choice();
    Label lblAgent = new Label();
    Choice choiceAgent = new Choice();
    Label label5 = new Label();
    Label label6 = new Label();

    public CurveShow(AsmModel pd, int type1) {
        super("数据走向...");
        this.local = pd;
        this.type = type1;

        try {
            this.jbInit();
        } catch (Exception var4) {
            var4.printStackTrace();
        }

    }

    private void jbInit() throws Exception {
        this.setLayout((LayoutManager)null);
        this.view.setBackground(Color.white);
        this.view.setBounds(new Rectangle(6, 26, 537, 316));
        this.setBackground(Color.gray);
        this.addWindowListener( new WindowAdapter((CurveShow)this) {

            {
                this.this$0 =this$0;
            }

            public void windowOpened(WindowEvent e) {
                this.this$0.this_windowOpened(e);
            }

            public void windowClosing(WindowEvent e) {
                this.this$0.this_windowClosing(e);
            }
        });
        this.choicelen.setBounds(new Rectangle(69, 355, 94, 21));
        this.choicelen.addItemListener(new ItemListener() {
            {
                this.this$0 = this$0;
            }

            public void itemStateChanged(ItemEvent e) {
                this.this$0.choicelen_itemStateChanged(e);
            }
        });

        int i;
        for(i = 0; i < 40; ++i) {
            this.choicelen.addItem(Integer.toString((i + 1) * 100));
        }

        if (this.type == 0) {
            this.choiceItem1.addItem("股票价格");
            this.choiceItem2.addItem("股票价格");
            this.choiceItem1.addItem("股息");
            this.choiceItem2.addItem("股息");
            this.choiceItem1.addItem("风险中性价格");
            this.choiceItem2.addItem("风险中性价格");
            this.choiceItem2.addItem("无");
            this.choiceItem1.select(0);
            this.choiceItem2.select(2);
        } else if (this.type == 1) {
            for(i = 0; i < this.local.asmModelParams.numBFagents; ++i) {
                this.choiceAgent.addItem(Integer.toString(i));
            }

            this.choiceItem1.addItem("股票需求量");
            this.choiceItem1.addItem("总财富");
            this.choiceItem1.addItem("股票份额");
            this.choiceItem1.addItem("现金量");
            this.choiceItem1.addItem("规则平均特定度");
            this.choiceItem1.addItem("预测量");
            this.choiceItem1.addItem("预测偏差");
            this.choiceItem1.addItem("预测系数a");
            this.choiceItem1.addItem("预测系数b");
            this.choiceItem2.addItem("股票需求量");
            this.choiceItem2.addItem("总财富");
            this.choiceItem2.addItem("股票份额");
            this.choiceItem2.addItem("现金量");
            this.choiceItem2.addItem("规则平均特定度");
            this.choiceItem2.addItem("预测量");
            this.choiceItem2.addItem("预测偏差");
            this.choiceItem2.addItem("预测系数a");
            this.choiceItem2.addItem("预测系数b");
            this.choiceItem2.addItem("无");
            this.choiceItem1.select(0);
            this.choiceItem2.select(this.choiceItem2.getItemCount() - 1);
        }

        this.label1.setText("显示长度：");
        this.label1.setBounds(new Rectangle(4, 360, 60, 12));
        this.label2.setText("观察项目1：");
        this.label2.setBounds(new Rectangle(171, 342, 70, 21));
        this.choiceItem1.setBounds(new Rectangle(239, 345, 122, 18));
        this.label3.setText("观察项目2：");
        this.label3.setBounds(new Rectangle(170, 369, 72, 15));
        this.choiceItem2.setBounds(new Rectangle(239, 367, 122, 18));
        this.lblAgent.setText("选择智能体编号：");
        this.lblAgent.setBounds(new Rectangle(435, 344, 107, 18));
        this.choiceAgent.setBounds(new Rectangle(436, 363, 94, 17));
        this.label5.setText("蓝色线");
        this.label5.setBounds(new Rectangle(364, 345, 47, 17));
        this.label6.setText("红色线");
        this.label6.setBounds(new Rectangle(364, 365, 40, 18));
        this.add(this.view, (Object)null);
        this.add(this.label2, (Object)null);
        this.add(this.choiceItem1, (Object)null);
        this.add(this.label3, (Object)null);
        this.add(this.choiceItem2, (Object)null);
        this.add(this.choicelen, (Object)null);
        this.add(this.label1, (Object)null);
        if (this.type == 1) {
            this.add(this.lblAgent, (Object)null);
            this.add(this.choiceAgent, (Object)null);
        }

        this.add(this.label5, (Object)null);
        this.add(this.label6, (Object)null);
        this.pack();
        this.addWindowListener(new WindowAdapter((CurveShow)this) {
            {
                this.this$0 = this$0;
            }

            public void windowClosing(WindowEvent e) {
                this.this$0.this_windowClosing(e);
            }
        });
    }

    void this_windowClosing(WindowEvent e) {
        this.hide();
        this.dispose();
    }

    void btnClose_actionPerformed(ActionEvent e) {
        this.hide();
        this.dispose();
    }

    void this_windowOpened(WindowEvent e) {
        this.gra = this.view.getGraphics();
        this.cyclemax = WorldVariants.cycleMax;
        this.repaint();
        if (this.runner1 == null) {
            this.runner1 = new Thread(this);
            this.runner1.start();
        }

    }

    public void paint(Graphics g) {
        Vector history = new Vector();
        double value1max = 100.0D;
        double value1min = -100.0D;
        double value2max = 100.0D;
        double value2min = -100.0D;
        double valuemax = 100.0D;
        double valuemin = -100.0D;
        String sName = "";
        if (this.type == 0) {
            history = this.local.world.Histories;
        } else if (this.type == 1) {
            this.nAgentIndex = this.choiceAgent.getSelectedIndex();
            Agent ag = (Agent)this.local.agentList.elementAt(this.nAgentIndex);
            history = ag.History;
        }

        int width = 517 - this.originx - 25;
        int height = 316 - this.originy;
        int step = this.local.modelTime;
        int nStart = 0;
        int nEnd = this.cycles;
        int size = history.size();
        if (step - this.cycles > 0) {
            nStart = step - this.cycles;
        }

        this.gra.clearRect(0, 0, 517, 316);
        int x = 0;
        int y = 0;
        int y0 = height - this.originy;
        boolean noneItem = false;

        int i;
        int x1;
        for(i = 0; i < this.cycles; ++i) {
            boolean isDrawn = true;
            x1 = i * width / this.cycles;
            double value1 = 0.0D;
            double value2 = 0.0D;
            if ((i + nStart) % this.cyclemax < size) {
                if (this.type == 0) {
                    WorldVariants wv = (WorldVariants)history.elementAt((i + nStart) % this.cyclemax);
                    switch(this.choiceItem1.getSelectedIndex()) {
                        case 0:
                            value1 = wv.price;
                            if (i == 0) {
                                sName = "价格";
                            }

                            value1max = this.local.asmModelParams.maxprice;
                            value1min = this.local.asmModelParams.minprice;
                            break;
                        case 1:
                            value1 = wv.dividend;
                            if (i == 0) {
                                sName = "股息";
                            }

                            value1max = this.local.asmModelParams.maxdividend;
                            value1min = this.local.asmModelParams.mindividend;
                            break;
                        case 2:
                            if (i == 0) {
                                sName = "股息/利息";
                            }

                            value1 = wv.risk_neutral;
                            value1max = this.local.asmModelParams.maxprice;
                            value1min = this.local.asmModelParams.minprice;
                    }

                    switch(this.choiceItem2.getSelectedIndex()) {
                        case 0:
                            value2 = wv.price;
                            value2max = this.local.asmModelParams.maxprice;
                            value2min = this.local.asmModelParams.minprice;
                            break;
                        case 1:
                            value2 = wv.dividend;
                            if (i == 0) {
                                sName = String.valueOf(String.valueOf(sName)).concat("-股息");
                            }

                            value2max = this.local.asmModelParams.maxdividend;
                            value2min = this.local.asmModelParams.mindividend;
                            break;
                        case 2:
                            if (i == 0) {
                                sName = String.valueOf(String.valueOf(sName)).concat("-股息/利息");
                            }

                            value2 = wv.risk_neutral;
                            value2max = this.local.asmModelParams.maxprice;
                            value2min = this.local.asmModelParams.minprice;
                            break;
                        case 3:
                            noneItem = true;
                            value2 = value1min;
                            value2max = value1max;
                            value2min = value1min;
                    }
                } else if (this.type == 1) {
                    AgentVariants agv = (AgentVariants)history.elementAt((i + nStart) % this.cyclemax);
                    if (i == 0) {
                        sName = this.choiceItem1.getSelectedItem();
                    }

                    AsmModel var10000;
                    AsmModel var10002;
                    double var35;
                    switch(this.choiceItem1.getSelectedIndex()) {
                        case 0:
                            value1 = agv.demand;
                            value1max = this.local.bfParams.maxbid;
                            value1min = -value1max;
                            break;
                        case 1:
                            value1 = agv.wealth;
                            var35 = this.local.asmModelParams.initialcash * (double)10;
                            var10002 = this.local;
                            value1max = var35 + this.local.asmModelParams.maxprice * (double)ASMParam.initholding;
                            value1min = 0.0D;
                            break;
                        case 2:
                            value1 = agv.position;
                            var10000 = this.local;
                            value1max = (double)ASMParam.initholding;
                            value1min = 0.0D;
                            break;
                        case 3:
                            value1 = agv.cash;
                            value1max = this.local.asmModelParams.initialcash * (double)10;
                            value1min = 0.0D;
                            break;
                        case 4:
                            value1 = agv.avspecificity;
                            value1max = (double)this.local.bfParams.condbits;
                            value1min = 0.0D;
                            break;
                        case 5:
                            value1 = agv.forecast;
                            value1max = this.local.asmModelParams.maxprice;
                            value1min = this.local.asmModelParams.minprice;
                            break;
                        case 6:
                            value1 = agv.realDeviation;
                            value1max = this.local.asmModelParams.maxprice - this.local.asmModelParams.minprice;
                            value1min = -value1max;
                            break;
                        case 7:
                            value1 = agv.pdcoeff;
                            value1max = this.local.bfParams.a_max;
                            value1min = 0.0D;
                            break;
                        case 8:
                            value1 = agv.offset;
                            value1max = this.local.bfParams.b_max;
                            value1min = this.local.bfParams.b_min;
                    }

                    switch(this.choiceItem2.getSelectedIndex()) {
                        case 0:
                            value2 = agv.demand;
                            value2max = this.local.bfParams.maxbid;
                            value2min = -value2max;
                            break;
                        case 1:
                            value2 = agv.wealth;
                            var35 = this.local.asmModelParams.initialcash * (double)10;
                            var10002 = this.local;
                            value2max = var35 + this.local.asmModelParams.maxprice * (double)ASMParam.initholding;
                            value2min = 0.0D;
                            break;
                        case 2:
                            value2 = agv.position;
                            var10000 = this.local;
                            value2max = (double)ASMParam.initholding;
                            value2min = 0.0D;
                            break;
                        case 3:
                            value2 = agv.cash;
                            value2max = this.local.asmModelParams.initialcash * (double)10;
                            value2min = 0.0D;
                            break;
                        case 4:
                            value2 = agv.avspecificity;
                            value2max = (double)this.local.bfParams.condbits;
                            value2min = 0.0D;
                            break;
                        case 5:
                            value2 = agv.forecast;
                            value2max = this.local.asmModelParams.maxprice;
                            value2min = this.local.asmModelParams.minprice;
                            break;
                        case 6:
                            value2 = agv.realDeviation;
                            value2max = this.local.asmModelParams.maxprice - this.local.asmModelParams.minprice;
                            value2min = -value1max;
                            break;
                        case 7:
                            value2 = agv.pdcoeff;
                            value2max = this.local.bfParams.a_max;
                            value2min = 0.0D;
                            break;
                        case 8:
                            value2 = agv.offset;
                            value2max = this.local.bfParams.b_max;
                            value2min = this.local.bfParams.b_min;
                            break;
                        case 9:
                            noneItem = true;
                            value2 = value1min;
                            value2max = value1max;
                            value2min = value1min;
                    }

                    if (i == 0 && !noneItem) {
                        sName = String.valueOf(String.valueOf(sName)).concat(String.valueOf(String.valueOf("-".concat(String.valueOf(String.valueOf(this.choiceItem2.getSelectedItem()))))));
                    }
                }
            } else {
                isDrawn = false;
                value1 = valuemin;
                value2 = valuemin;
            }

            valuemax = value1max;
            valuemin = value1min;
            if (!noneItem) {
                if (value1max < value2max) {
                    valuemax = value2max;
                }

                if (value1min > value2min) {
                    valuemin = value2min;
                }
            }

            if (valuemax == valuemin) {
                valuemin = valuemax - (double)100;
            }

            int y1 = (int)((double)height * (value1 - valuemin) / (valuemax - valuemin));
            if (y1 <= 0) {
                y1 = 1;
            } else if (y1 >= height) {
                y1 = height;
            }

            if (isDrawn) {
                this.gra.setColor(Color.blue);
                this.gra.drawLine(x + this.originx, height - y, x1 + this.originx, height - y1);
            }

            int y2 = (int)((double)height * (value2 - valuemin) / (valuemax - valuemin));
            if (y2 <= 0) {
                y2 = 1;
            } else if (y2 >= height) {
                y2 = height;
            }

            if (isDrawn && !noneItem) {
                this.gra.setColor(Color.red);
                this.gra.drawLine(x + this.originx, height - y0, x1 + this.originx, height - y2);
            }

            x = x1;
            y = y1;
            y0 = y2;
        }

        this.gra.setColor(Color.black);
        this.gra.drawLine(this.originx, height, width + this.originx, height);
        this.gra.drawLine(this.originx, height, this.originx, 0);
        this.gra.drawString("时间", width + this.originx, height);
        this.gra.drawString(sName, this.originx - 35, this.originy / 2);
        this.setTitle(String.valueOf(String.valueOf(sName)).concat("（曲线图）"));

        for(i = 0; i < 10; ++i) {
            x1 = i * width / 10 + this.originx;
            this.gra.drawLine(x1, height, x1, height - 2);
            String txt;
            if (step > this.cycles) {
                txt = Integer.toString(step - this.cycles + i * this.cycles / 10);
            } else {
                txt = Integer.toString(i * this.cycles / 10);
            }

            this.gra.drawString(txt, x1, height + 12);
        }

        for(i = 0; i <= 9; ++i) {
            x1 = this.originx;
            int y3 = (10 - i) * height / 10;
            this.gra.drawLine(x1, y3, x1 + 2, y3);
            float num = (float)((double)i * (valuemax - valuemin) / 10.0D + valuemin);
            String txt = Float.toString(num);
            if (txt.length() >= 5) {
                txt = txt.substring(0, 5);
            }

            this.gra.drawString(txt, x1 - 30, y3 + 5);
        }

        super.paint(g);
    }

    void choicelen_itemStateChanged(ItemEvent e) {
        this.cycles = (this.choicelen.getSelectedIndex() + 1) * 100;
        this.repaint();
    }

    void btnRefresh_actionPerformed(ActionEvent e) {
        this.repaint();
    }

    public void stop() {
        if (this.runner1 != null) {
            this.runner1.stop();
            this.runner1 = null;
        }

    }

    public void run() {
        while(true) {
            this.repaint();

            try {
                Thread.sleep(1000L);
            } catch (InterruptedException var2) {
            }
        }
    }
}
