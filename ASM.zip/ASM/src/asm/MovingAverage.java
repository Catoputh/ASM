//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package asm;

class MovingAverage {
    public int width;
    public int numInputs;
    public double[] maInputs;
    public int arrayPosition;
    public double sumOfInputs;
    public double uncorrectedSum;
    public double expWMA;
    public double aweight;
    public double bweight;

    MovingAverage() {
    }

    void initWidth(int w) {
        this.width = w;
        this.maInputs = new double[w];

        for(int i = 0; i < w; ++i) {
            this.maInputs[i] = 0.0D;
        }

        this.numInputs = 0;
        this.sumOfInputs = 0.0D;
        this.arrayPosition = 0;
        this.uncorrectedSum = 0.0D;
        this.bweight = -Math.exp(-1.0D / (double)w);
        this.aweight = 1.0D - this.bweight;
    }

    void initWidth(int w, double val) {
        this.width = w;
        this.maInputs = new double[w];

        for(int i = 0; i < w; ++i) {
            this.maInputs[i] = val;
        }

        this.numInputs = w;
        this.sumOfInputs = (double)w * val;
        this.arrayPosition = 0;
        this.uncorrectedSum = (double)w * val;
        this.bweight = -Math.exp(-1.0D / (double)w);
        this.aweight = 1.0D - this.bweight;
        this.expWMA = val;
    }

    int getNumInputs() {
        return this.numInputs;
    }

    double getMA() {
        if (this.numInputs == 0) {
            return 0.0D;
        } else {
            double movingAverage;
            if (this.numInputs < this.width) {
                movingAverage = this.sumOfInputs / (double)this.numInputs;
            } else {
                movingAverage = this.sumOfInputs / (double)this.width;
            }

            return movingAverage;
        }
    }

    double getAverage() {
        return this.numInputs == 0 ? 0.0D : this.uncorrectedSum / (double)this.numInputs;
    }

    double getEWMA() {
        return this.expWMA;
    }

    void addValue(double x) {
        this.arrayPosition = (this.width + this.numInputs) % this.width;
        if (this.numInputs < this.width) {
            this.sumOfInputs += x;
            this.maInputs[this.arrayPosition] = x;
        } else {
            this.sumOfInputs = this.sumOfInputs - this.maInputs[this.arrayPosition] + x;
            this.maInputs[this.arrayPosition] = x;
        }

        ++this.numInputs;
        this.uncorrectedSum += x;
        this.expWMA = this.aweight * this.expWMA + this.bweight * x;
    }
}
