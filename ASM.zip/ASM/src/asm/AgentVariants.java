//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package asm;

public class AgentVariants {
    public double demand;
    public double profit;
    public double wealth;
    public double position;
    public double cash;
    public int currentTime;
    public double avspecificity;
    public double forecast;
    public double global_mean;
    public double realDeviation;
    public double variance;
    public double pdcoeff;
    public double offset;
    public double divisor;
    public int gacount;

    public AgentVariants() {
    }
}
