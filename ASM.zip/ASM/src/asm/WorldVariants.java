//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package asm;

public class WorldVariants {
    public double price;
    public double dividend;
    public double rate;
    public double risk_neutral;
    public int currentTime;
    static int cycleMax = 50000;

    public WorldVariants() {
    }
}
