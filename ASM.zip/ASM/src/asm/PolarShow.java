//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package asm;

import java.awt.Choice;
import java.awt.Color;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Label;
import java.awt.LayoutManager;
import java.awt.Panel;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class PolarShow extends Frame implements Runnable {
    Panel view = new Panel();
    Thread runner1;
    Graphics gra;
    int cycles = 100;
    int cyclemax;
    int originx = 40;
    int originy = 20;
    int type;
    int itemCount = 9;
    double[] maxvalue;
    public int nAgentIndex = 0;
    AsmModel local;
    Label label2 = new Label();
    Choice choiceItem = new Choice();

    public PolarShow(AsmModel pd, int type1) {
        super("数据柱状图");
        this.local = pd;
        this.type = type1;

        try {
            this.jbInit();
        } catch (Exception var4) {
            var4.printStackTrace();
        }

    }

    private void jbInit() throws Exception {
        this.setLayout((LayoutManager)null);
        this.view.setBackground(Color.white);
        this.view.setBounds(new Rectangle(7, 25, 537, 316));
        this.setBackground(Color.gray);

        this.addWindowListener(new WindowAdapter((PolarShow)this) {
            private final Object this$0;

            {
                this.this$0 = this$0;
            }

            public void windowOpened(WindowEvent e) {
                this.this$0.this_windowOpened(e);
            }

            public void windowClosing(WindowEvent e) {
                this.this$0.this_windowClosing(e);
            }
        });
        this.choiceItem.addItem("股票需求量");
        this.choiceItem.addItem("总财富");
        this.choiceItem.addItem("股票份额");
        this.choiceItem.addItem("现金量");
        this.choiceItem.addItem("规则平均特定度");
        this.choiceItem.addItem("预测量");
        this.choiceItem.addItem("预测偏差");
        this.choiceItem.addItem("预测系数a");
        this.choiceItem.addItem("预测系数b");
        this.label2.setText("查看项目：");
        this.label2.setBounds(new Rectangle(11, 358, 66, 17));
        this.choiceItem.setBounds(new Rectangle(73, 355, 99, 18));
        this.maxvalue = new double[this.itemCount];

        for(int i = 0; i < this.itemCount; ++i) {
            this.maxvalue[i] = 0.01D;
        }

        this.choiceItem.select(2);
        this.add(this.view, (Object)null);
        this.add(this.label2, (Object)null);
        this.add(this.choiceItem, (Object)null);
        this.pack();
        this.addWindowListener(new WindowAdapter((PolarShow)this) {

            {
                this.this$0 = this$0;
            }
            public void windowClosing(WindowEvent e) {
                this.this$0.this_windowClosing(e);
            }
        });
    }

    void this_windowClosing(WindowEvent e) {
        this.hide();
        this.dispose();
    }

    void btnClose_actionPerformed(ActionEvent e) {
        this.hide();
        this.dispose();
    }

    void this_windowOpened(WindowEvent e) {
        this.gra = this.view.getGraphics();
        this.repaint();
        if (this.runner1 == null) {
            this.runner1 = new Thread(this);
            this.runner1.start();
        }

    }

    public void paint(Graphics g) {
        int agCount = this.local.agentList.size();
        double[] values = new double[agCount];
        double maxval = 0.01D;

        int width;
        for(width = 0; width < agCount; ++width) {
            Agent ag = (Agent)this.local.agentList.elementAt(width);
            switch(this.choiceItem.getSelectedIndex()) {
                case 0:
                    values[width] = ag.demand;
                    break;
                case 1:
                    values[width] = ag.wealth;
                    break;
                case 2:
                    values[width] = ag.position;
                    break;
                case 3:
                    values[width] = ag.cash;
                    break;
                case 4:
                    values[width] = ag.avspecificity;
                    break;
                case 5:
                    values[width] = ag.forecast;
                    break;
                case 6:
                    values[width] = Math.abs(ag.realDeviation);
                    break;
                case 7:
                    values[width] = ag.pdcoeff;
                    break;
                case 8:
                    values[width] = ag.offset;
            }

            if (values[width] > maxval) {
                maxval = values[width];
            }
        }

        if (maxval > this.maxvalue[this.choiceItem.getSelectedIndex()] || maxval / this.maxvalue[this.choiceItem.getSelectedIndex()] < 0.01D) {
            this.maxvalue[this.choiceItem.getSelectedIndex()] = maxval;
        }

        width = 517 - this.originx - 25;
        int height = 316 - this.originy;
        this.gra.clearRect(0, 0, 517, 316);
        boolean x = false;
        boolean y = false;
        int var10000 = height - this.originy;

        int i;
        int x3;
        int y3;
        for(i = 0; i < agCount; ++i) {
            x3 = i * width / agCount;
            y3 = (i + 1) * width / agCount;
            double rect_height;
            if (this.maxvalue[this.choiceItem.getSelectedIndex()] != (double)0) {
                rect_height = values[i] / this.maxvalue[this.choiceItem.getSelectedIndex()];
            } else {
                rect_height = 0.0D;
            }

            int rect_width = width / agCount - 3;
            this.gra.setColor(Color.blue);
            this.gra.fillRect(x3 + this.originx + 3, (int)(((double)1 - rect_height) * (double)height), rect_width, (int)(rect_height * (double)height));
        }

        this.gra.setColor(Color.black);
        this.gra.drawLine(this.originx, height, width + this.originx, height);
        this.gra.drawLine(this.originx, height, this.originx, 0);
        this.gra.drawString("Agent编号", width + this.originx, height);
        this.gra.drawString(this.choiceItem.getSelectedItem(), this.originx - 40, this.originy / 2);
        this.setTitle(String.valueOf(String.valueOf(this.choiceItem.getSelectedItem())).concat("（柱状图）"));

        String txt;
        for(i = 0; i < agCount; ++i) {
            x3 = i * width / agCount + this.originx;
            this.gra.drawLine(x3, height, x3, height - 2);
            txt = Integer.toString(i);
            this.gra.drawString(txt, x3, height + 12);
        }

        for(i = 0; i <= 9; ++i) {
            x3 = this.originx;
            y3 = (10 - i) * height / 10;
            this.gra.drawLine(x3, y3, x3 + 2, y3);
            txt = Float.toString((float)((double)i * this.maxvalue[this.choiceItem.getSelectedIndex()] / 10.0D));
            if (txt.length() >= 5) {
                txt = txt.substring(0, 5);
            }

            this.gra.drawString(txt, x3 - 40, y3 + 10);
        }

        super.paint(g);
    }

    void btnRefresh_actionPerformed(ActionEvent e) {
        this.repaint();
    }

    public void stop() {
        if (this.runner1 != null) {
            this.runner1.stop();
            this.runner1 = null;
        }

    }

    public void run() {
        while(true) {
            this.repaint();

            try {
                Thread.sleep(1000L);
            } catch (InterruptedException var2) {
            }
        }
    }
}
