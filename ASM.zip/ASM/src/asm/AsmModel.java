package asm;

import java.util.Vector;

public class AsmModel {
    int modelTime = 0;
    Vector agentList;
    Specialist specialist = new Specialist();
    Dividend dividendProcess;
    World world;
    static asm localasm;
    AgentParam bfParams;
    ASMParam asmModelParams;

    public AsmModel(asm local) {
        this.asmModelParams = local.ASMParams;
        this.bfParams = local.AgentParams;
        this.agentList = new Vector();
        localasm = local;
    }

    int getNumBFagents() {
        return this.asmModelParams.numBFagents;
    }

    double getInitialCash() {
        return this.asmModelParams.initialcash;
    }

    public void OneStep() {
        this.periodStepDividend();

        int i;
        Agent ag;
        for(i = 0; i < this.asmModelParams.numBFagents; ++i) {
            ag = (Agent)this.agentList.elementAt(i);
            ag.creditEarningsAndPayTaxes();
        }

        this.world.updateWorld();

        for(i = 0; i < this.asmModelParams.numBFagents; ++i) {
            ag = (Agent)this.agentList.elementAt(i);
            ag.prepareForTrading();
        }

        this.periodStepPrice();
        this.specialist.completeTrades(this.agentList, this.world);

        for(i = 0; i < this.asmModelParams.numBFagents; ++i) {
            ag = (Agent)this.agentList.elementAt(i);
            ag.updatePerformance();
            ag.RecordHistory(this.modelTime);
        }

        this.world.RecordHistory(this.modelTime);
        localasm.setStatus(String.valueOf(String.valueOf((new StringBuffer("仿真周期：")).append(String.valueOf(this.modelTime)).append(",正在运行.."))));
    }

    long getModelTime() {
        return (long)this.modelTime;
    }

    void buildObjects() {
        localasm.setStatus("正在初始化股息流随机模型...");
        this.dividendProcess = new Dividend();
        this.dividendProcess.initNormal();
        this.dividendProcess.baseline = this.asmModelParams.baseline;
        this.dividendProcess.mindividend = this.asmModelParams.mindividend;
        this.dividendProcess.maxdividend = this.asmModelParams.maxdividend;
        this.dividendProcess.amplitude = this.asmModelParams.amplitude;
        this.dividendProcess.setPeriod(this.asmModelParams.period);
        this.dividendProcess.setDerivedParams();
        localasm.setStatus("正在初始化虚拟股市世界模型...");
        this.world = new World();
        this.world.setintrate(this.asmModelParams.intrate);
        if (this.asmModelParams.exponentialMAs == 1) {
            this.world.setExponentialMAs(true);
        } else {
            this.world.setExponentialMAs(false);
        }

        this.world.initWithBaseline(this.asmModelParams.baseline);
        localasm.setStatus("正在初始化市场分析专家...");
        this.specialist = new Specialist();
        this.specialist.maxprice = this.asmModelParams.maxprice;
        this.specialist.minprice = this.asmModelParams.minprice;
        this.specialist.setTaup(this.asmModelParams.taup);
        this.specialist.setSPtype(this.asmModelParams.sptype);
        this.specialist.maxiterations = this.asmModelParams.maxiterations;
        this.specialist.minexcess = this.asmModelParams.minexcess;
        this.specialist.eta = this.asmModelParams.eta;
        this.specialist.rea = this.asmModelParams.rea;
        this.specialist.reb = this.asmModelParams.reb;
        this.agentList.removeAllElements();

        for(int i = 0; i < this.asmModelParams.numBFagents; ++i) {
            Agent agent = new Agent(this);
            agent.setBFParameterObject(this.bfParams);
            agent.setWorld(this.world);
            agent.myID = i;
            agent.setintrate(this.asmModelParams.intrate);
            agent.setminHolding(this.asmModelParams.minholding, this.asmModelParams.mincash);
            agent.initialcash = this.asmModelParams.initialcash;
            agent.setInitialHoldings();
            agent.position = (double)ASMParam.initholding;
            agent.initForecasts();
            this.agentList.addElement(agent);
            localasm.setStatus(String.valueOf(String.valueOf((new StringBuffer("正在初始化Agent：")).append(String.valueOf(i + 1)).append("/").append(String.valueOf(this.asmModelParams.numBFagents)))));
        }

        localasm.setStatus("初始化完毕！");
    }

    public void doWarmupStep() {
        double div = this.dividendProcess.dividend();
        this.world.setDividend(div);
        this.world.updateWorld();
        this.world.setPrice(div / this.asmModelParams.intrate);
    }

    void periodStepDividend() {
        ++this.modelTime;
        this.world.setDividend(this.dividendProcess.dividend());
    }

    void periodStepPrice() {
        this.world.setPrice(this.specialist.performTrading(this.agentList, this.world));
    }

    public void terminate() {
        this.agentList.removeAllElements();
    }
}
