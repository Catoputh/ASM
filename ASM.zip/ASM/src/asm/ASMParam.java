//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package asm;

import java.awt.Frame;

public class ASMParam extends Frame {
    public int numBFagents = 30;
    public static float initholding;
    public double initialcash;
    public double minholding;
    public double mincash;
    public double intrate;
    public double baseline;
    public double mindividend;
    public double maxdividend;
    public double amplitude;
    public int period;
    public int exponentialMAs;
    public double maxprice;
    public double minprice;
    public double taup;
    public int sptype;
    public int maxiterations;
    public double minexcess;
    public double eta;
    public double etamax;
    public double etamin;
    public double rea;
    public double reb;
    public int randomSeed;
    public double tauv;
    public double lambda;
    public double maxbid;
    public double initvar;
    public double maxdev;

    public ASMParam() {
        initholding = 5.0F;
        this.initialcash = 10000.0D;
        this.minholding = 0.0D;
        this.mincash = 0.0D;
        this.intrate = 0.1D;
        this.baseline = 10.0D;
        this.mindividend = 5.0E-5D;
        this.maxdividend = 100.0D;
        this.amplitude = 0.14178D;
        this.period = 0;
        this.exponentialMAs = 1;
        this.maxprice = 500.0D;
        this.minprice = 0.001D;
        this.taup = 50.0D;
        this.sptype = 3;
        this.maxiterations = 1000;
        this.minexcess = 0.01D;
        this.eta = 5.0E-4D;
        this.etamax = 0.05D;
        this.etamin = 1.0E-5D;
        this.rea = 9.0D;
        this.reb = 2.0D;
        this.randomSeed = 0;
        this.tauv = 50.0D;
        this.lambda = 0.3D;
        this.maxbid = 10.0D;
        this.initvar = 0.400021D;
        this.maxdev = 100.0D;
    }
}
