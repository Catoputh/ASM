package asm;

import java.applet.Applet;
import java.awt.Button;
import java.awt.Dimension;
import java.awt.Event;
import java.awt.Frame;
import java.awt.Label;
import java.awt.LayoutManager;
import java.awt.Rectangle;
import java.awt.TextField;
import java.awt.Toolkit;
import java.awt.event.WindowEvent;

public class asm extends Applet implements Runnable {
    boolean isStandalone = false;
    boolean bFirst = true;
    Button btnStart = new Button();
    Button btnStop = new Button();
    Label label1 = new Label();
    TextField txtAgentNum = new TextField();
    Button btnWorld = new Button();
    Label label2 = new Label();
    TextField txtStatus = new TextField();
    Button btnAgentView = new Button();
    Button btnPolar = new Button();
    Label label3 = new Label();
    TextField txtGAP = new TextField();
    Label label4 = new Label();
    TextField txtRuleNum = new TextField();
    Label label5 = new Label();
    Label label6 = new Label();
    Label label7 = new Label();
    TextField txtMutation = new TextField();
    Label label8 = new Label();
    TextField txtCross = new TextField();
    Button btnContinue = new Button();
    Thread runner;
    boolean running;
    public ASMParam ASMParams = new ASMParam();
    public AgentParam AgentParams = new AgentParam();
    public AsmModel model;
    Button btnRulesView = new Button();
    Button btnStep = new Button();

    public String getParameter(String key, String def) {
        return this.isStandalone ? System.getProperty(key, def) : (this.getParameter(key) != null ? this.getParameter(key) : def);
    }

    public asm() {
    }

    public void init() {
        try {
            this.jbInit();
        } catch (Exception var2) {
            var2.printStackTrace();
        }

    }

    private void jbInit() throws Exception {
        this.btnStart.setLabel("开始");
        this.btnStart.setBounds(new Rectangle(5, 270, 65, 22));
        this.setLayout((LayoutManager)null);
        this.btnStop.setLabel("停止");
        this.btnStop.setBounds(new Rectangle(68, 270, 70, 22));
        this.label1.setText("Agent的数目：");
        this.label1.setBounds(new Rectangle(11, 12, 83, 26));
        this.txtAgentNum.setText("30");
        this.txtAgentNum.setBounds(new Rectangle(122, 11, 47, 21));
        this.btnWorld.setEnabled(false);
        this.btnWorld.setLabel("曲线图");
        this.btnWorld.setBounds(new Rectangle(93, 123, 112, 24));
        this.label2.setText("世界状态：");
        this.label2.setBounds(new Rectangle(4, 240, 62, 22));
        this.txtStatus.setEditable(false);
        this.txtStatus.setText("就绪");
        this.txtStatus.setBounds(new Rectangle(69, 242, 226, 19));
        this.btnAgentView.setEnabled(false);
        this.btnAgentView.setLabel("曲线图");
        this.btnAgentView.setBounds(new Rectangle(95, 167, 91, 22));
        this.btnPolar.setEnabled(false);
        this.btnPolar.setLabel("柱状图");
        this.btnPolar.setBounds(new Rectangle(186, 167, 90, 22));
        this.label3.setText("执行遗传算法频率：");
        this.label3.setBounds(new Rectangle(10, 43, 113, 20));
        this.txtGAP.setText("250");
        this.txtGAP.setBounds(new Rectangle(122, 43, 46, 20));
        this.label4.setText("规则数目：");
        this.label4.setBounds(new Rectangle(176, 13, 60, 17));
        this.txtRuleNum.setText("100");
        this.txtRuleNum.setBounds(new Rectangle(238, 11, 45, 20));
        this.label5.setText("查看世界：");
        this.label5.setBounds(new Rectangle(10, 123, 66, 21));
        this.label6.setText("查看Agent：");
        this.label6.setBounds(new Rectangle(10, 162, 73, 22));
        this.label7.setText("变异概率：");
        this.label7.setBounds(new Rectangle(175, 43, 60, 15));
        this.txtMutation.setText("0.01");
        this.txtMutation.setBounds(new Rectangle(237, 41, 47, 17));
        this.label8.setText("交叉概率：");
        this.label8.setBounds(new Rectangle(10, 66, 68, 17));
        this.txtCross.setText("0.3");
        this.txtCross.setBounds(new Rectangle(80, 66, 52, 17));
        this.btnContinue.setEnabled(false);
        this.btnContinue.setLabel("暂停");
        this.btnContinue.setBounds(new Rectangle(137, 270, 70, 22));
        this.btnRulesView.setEnabled(false);
        this.btnRulesView.setLabel("查看规则");
        this.btnRulesView.setBounds(new Rectangle(94, 196, 91, 25));
        this.btnStep.setEnabled(false);
        this.btnStep.setLabel("单步运行");
        this.btnStep.setBounds(new Rectangle(206, 270, 87, 22));
        this.add(this.btnStart, (Object)null);
        this.add(this.txtStatus, (Object)null);
        this.add(this.label1, (Object)null);
        this.add(this.label3, (Object)null);
        this.add(this.txtGAP, (Object)null);
        this.add(this.txtAgentNum, (Object)null);
        this.add(this.label5, (Object)null);
        this.add(this.label4, (Object)null);
        this.add(this.txtRuleNum, (Object)null);
        this.add(this.label2, (Object)null);
        this.add(this.label7, (Object)null);
        this.add(this.txtMutation, (Object)null);
        this.add(this.label8, (Object)null);
        this.add(this.txtCross, (Object)null);
        this.add(this.label6, (Object)null);
        this.add(this.btnPolar, (Object)null);
        this.add(this.btnStop, (Object)null);
        this.add(this.btnContinue, (Object)null);
        this.add(this.btnStep, (Object)null);
        this.add(this.btnAgentView, (Object)null);
        this.add(this.btnRulesView, (Object)null);
        this.add(this.btnWorld, (Object)null);
    }

    public String getAppletInfo() {
        return "Applet Information";
    }

    public String[][] getParameterInfo() {
        return null;
    }

    public static void main(String[] args) {
        asm applet = new asm();
        applet.isStandalone = true;
        Frame frame = new Frame() {
            protected void processWindowEvent(WindowEvent e) {
                super.processWindowEvent(e);
                if (e.getID() == 201) {
                    System.exit(0);
                }

            }

            public synchronized void setTitle(String title) {
                super.setTitle(title);
                this.enableEvents(64L);
            }
        };
        frame.setTitle("Applet Frame");
        frame.add(applet, "Center");
        applet.init();
        applet.start();
        frame.setSize(400, 320);
        Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
        frame.setLocation((d.width - frame.getSize().width) / 2, (d.height - frame.getSize().height) / 2);
        frame.setVisible(true);
    }

    public void setStatus(String txt) {
        this.txtStatus.setText(txt);
    }

    public boolean action(Event evt, Object o) {
        if (evt.target == this.btnStart) {
            this.running = true;
            this.btnStart.setEnabled(false);
            this.btnContinue.setEnabled(true);
            this.txtAgentNum.setEnabled(false);
            this.txtGAP.setEnabled(false);
            this.txtMutation.setEnabled(false);
            this.txtCross.setEnabled(false);
            this.txtRuleNum.setEnabled(false);
            this.ASMParams.numBFagents = Integer.parseInt(this.txtAgentNum.getText());
            if (this.ASMParams.numBFagents <= 0) {
                this.ASMParams.numBFagents = 1;
                this.txtAgentNum.setText(String.valueOf(this.ASMParams.numBFagents));
            }

            this.AgentParams.gafrequency = Integer.parseInt(this.txtGAP.getText());
            if (this.AgentParams.gafrequency < 10) {
                this.AgentParams.gafrequency = 10;
                this.txtGAP.setText("10");
            }

            this.AgentParams.numfcasts = Integer.parseInt(this.txtRuleNum.getText());
            if (this.AgentParams.numfcasts < 1) {
                this.AgentParams.numfcasts = 1;
                this.txtRuleNum.setText("1");
            }

            this.AgentParams.pmutation = Double.valueOf(this.txtMutation.getText());
            if (this.AgentParams.pmutation <= (double)0 || this.AgentParams.pmutation >= (double)1) {
                this.AgentParams.pmutation = 0.5D;
                this.txtMutation.setText("0.5");
            }

            this.AgentParams.pcrossover = Double.valueOf(this.txtCross.getText());
            if (this.AgentParams.pcrossover <= (double)0 || this.AgentParams.pcrossover >= (double)1) {
                this.AgentParams.pcrossover = 0.5D;
                this.txtMutation.setText("0.5");
            }

            this.AgentParams.reinit();
            return true;
        } else if (evt.target == this.btnStop) {
            this.btnStart.setEnabled(true);
            this.btnPolar.setEnabled(false);
            this.btnWorld.setEnabled(false);
            this.btnRulesView.setEnabled(false);
            this.btnAgentView.setEnabled(false);
            this.btnContinue.setEnabled(false);
            this.txtAgentNum.setEnabled(true);
            this.txtGAP.setEnabled(true);
            this.txtMutation.setEnabled(true);
            this.txtCross.setEnabled(true);
            this.txtRuleNum.setEnabled(true);
            this.running = false;
            this.setStatus("就绪...");
            this.bFirst = true;
            return true;
        } else {
            CurveShow ctl1;
            if (evt.target == this.btnWorld) {
                ctl1 = new CurveShow(this.model, 0);
                ctl1.setSize(550, 400);
                ctl1.show();
                return true;
            } else if (evt.target == this.btnAgentView) {
                ctl1 = new CurveShow(this.model, 1);
                ctl1.setSize(550, 400);
                ctl1.show();
                return true;
            } else if (evt.target == this.btnPolar) {
                PolarShow ctl = new PolarShow(this.model, 0);
                ctl.setSize(550, 400);
                ctl.show();
                return true;
            } else if (evt.target == this.btnContinue) {
                if (this.btnContinue.getLabel() == "暂停") {
                    this.btnContinue.setLabel("继续");
                    this.btnStep.setEnabled(true);
                    this.running = false;
                } else {
                    this.btnContinue.setLabel("暂停");
                    this.btnStep.setEnabled(false);
                    this.running = true;
                }

                return true;
            } else {
                if (evt.target == this.btnRulesView) {
                    RuleView ctl = new RuleView(this.model);
                    ctl.setSize(800, 480);
                    ctl.show();
                } else if (evt.target == this.btnStep) {
                    this.model.OneStep();
                    return true;
                }

                return false;
            }
        }
    }

    public void start() {
        if (this.runner == null) {
            this.runner = new Thread(this);
            this.runner.start();
        }

    }

    public void stop() {
        if (this.runner != null) {
            this.runner.stop();
            this.runner = null;
            this.running = false;
        }

    }

    public void run() {
        while(true) {
            if (this.running) {
                if (this.bFirst) {
                    this.model = new AsmModel(this);
                    this.model.buildObjects();
                    this.setStatus("股市预运行（没有Agent参与）");

                    for(int j = 0; j < 502; ++j) {
                        this.model.doWarmupStep();
                    }

                    this.btnPolar.setEnabled(true);
                    this.btnWorld.setEnabled(true);
                    this.btnAgentView.setEnabled(true);
                    this.btnRulesView.setEnabled(true);
                    this.bFirst = false;
                }

                this.model.OneStep();
            }

            try {
                Thread.sleep(100L);
            } catch (InterruptedException var3) {
            }
        }
    }

    public void terminate() {
        this.model.terminate();
    }
}
