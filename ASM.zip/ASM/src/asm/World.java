//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package asm;

import java.util.Vector;

public class World {
    public double intrate;
    public double dividendscale;
    public int[] pupdown;
    public int[] dupdown;
    public int history_top;
    public int updown_top;
    public double price;
    public double oldprice;
    public double dividend;
    public double olddividend;
    public double saveddividend;
    public double savedprice;
    public double riskNeutral;
    public double profitperunit;
    public double returnratio;
    public int[] malength;
    public int nworldbits;
    public int[] realworld;
    public boolean exponentialMAs;
    public MovingAverage[] priceMA;
    public MovingAverage[] divMA;
    public MovingAverage[] oldpriceMA;
    public MovingAverage[] olddivMA;
    public Vector Histories;
    double[] divhistory;
    double[] pricehistory;
    static int NULLBIT = -1;
    static int PUPDOWNBITNUM = 42;
    static int NWORLDBITS = 61;
    static int NRATIOS = 10;
    static int EQ = 0;
    static int UPDOWNLOOKBACK = 5;
    static int NMAS = 4;
    static int MAXHISTORY = 500;
    String[][] bitnamelist = new String[][]{{"on", "dummy bit -- always on"}, {"off", "dummy bit -- always off"}, {"random", "random on or off"}, {"dup", "dividend went up this period"}, {"dup1", "dividend went up one period ago"}, {"dup2", "dividend went up two periods ago"}, {"dup3", "dividend went up three periods ago"}, {"dup4", "dividend went up four periods ago"}, {"d5up", "5-period MA of dividend went up"}, {"d20up", "20-period MA of dividend went up"}, {"d100up", "100-period MA of dividend went up"}, {"d500up", "500-period MA of dividend went up"}, {"d>d5", "dividend > 5-period MA"}, {"d>d20", "dividend > 20-period MA"}, {"d>d100", "dividend > 100-period MA"}, {"d>d500", "dividend > 500-period MA"}, {"d5>d20", "dividend: 5-period MA > 20-period MA"}, {"d5>d100", "dividend: 5-period MA > 100-period MA"}, {"d5>d500", "dividend: 5-period MA > 500-period MA"}, {"d20>d100", "dividend: 20-period MA > 100-period MA"}, {"d20>d500", "dividend: 20-period MA > 500-period MA"}, {"d100>d500", "dividend: 100-period MA > 500-period MA"}, {"d/md>1/4", "dividend/mean dividend > 1/4"}, {"d/md>1/2", "dividend/mean dividend > 1/2"}, {"d/md>3/4", "dividend/mean dividend > 3/4"}, {"d/md>7/8", "dividend/mean dividend > 7/8"}, {"d/md>1", "dividend/mean dividend > 1  "}, {"d/md>9/8", "dividend/mean dividend > 9/8"}, {"d/md>5/4", "dividend/mean dividend > 5/4"}, {"d/md>3/2", "dividend/mean dividend > 3/2"}, {"d/md>2", "dividend/mean dividend > 2"}, {"d/md>4", "dividend/mean dividend > 4"}, {"pr/d>1/4", "price*interest/dividend > 1/4"}, {"pr/d>1/2", "price*interest/dividend > 1/2"}, {"pr/d>3/4", "price*interest/dividend > 3/4"}, {"pr/d>7/8", "price*interest/dividend > 7/8"}, {"pr/d>1", "price*interest/dividend > 1"}, {"pr/d>9/8", "price*interest/dividend > 9/8"}, {"pr/d>5/4", "price*interest/dividend > 5/4"}, {"pr/d>3/2", "price*interest/dividend > 3/2"}, {"pr/d>2", "price*interest/dividend > 2"}, {"pr/d>4", "price*interest/dividend > 4"}, {"pup", "price went up this period"}, {"pup1", "price went up one period ago"}, {"pup2", "price went up two periods ago"}, {"pup3", "price went up three periods ago"}, {"pup4", "price went up four periods ago"}, {"p5up", "5-period MA of price went up"}, {"p20up", "20-period MA of price went up"}, {"p100up", "100-period MA of price went up"}, {"p500up", "500-period MA of price went up"}, {"p>p5", "price > 5-period MA"}, {"p>p20", "price > 20-period MA"}, {"p>p100", "price > 100-period MA"}, {"p>p500", "price > 500-period MA"}, {"p5>p20", "price: 5-period MA > 20-period MA"}, {"p5>p100", "price: 5-period MA > 100-period MA"}, {"p5>p500", "price: 5-period MA > 500-period MA"}, {"p20>p100", "price: 20-period MA > 100-period MA"}, {"p20>p500", "price: 20-period MA > 500-period MA"}, {"p100>p500", "price: 100-period MA > 500-period MA"}};
    double[] ratios = new double[]{0.25D, 0.5D, 0.75D, 0.875D, 1.0D, 1.125D, 1.25D, 1.5D, 2.0D, 4.0D};

    public World() {
        this.pupdown = new int[UPDOWNLOOKBACK];
        this.dupdown = new int[UPDOWNLOOKBACK];
        this.malength = new int[NMAS];
        this.priceMA = new MovingAverage[NMAS];
        this.divMA = new MovingAverage[NMAS];
        this.oldpriceMA = new MovingAverage[NMAS];
        this.olddivMA = new MovingAverage[NMAS];
        this.Histories = new Vector();
    }

    String descriptionOfBit(int n) {
        if (n == NULLBIT) {
            return "(Unused bit for spacing)";
        } else {
            return n >= 0 && n < NWORLDBITS ? this.bitnamelist[n][1] : "(Invalid world bit)";
        }
    }

    String nameOfBit(int n) {
        if (n == NULLBIT) {
            return "null";
        } else {
            return n >= 0 && n < NWORLDBITS ? this.bitnamelist[n][0] : "";
        }
    }

    int bitNumberOf(String name) {
        int n;
        for(n = 0; n < NWORLDBITS && !this.bitnamelist[n][0].equals(name); ++n) {
        }

        if (n >= NWORLDBITS) {
            n = NULLBIT;
        }

        return n;
    }

    void setintrate(double rate) {
        this.intrate = rate;
    }

    void setExponentialMAs(boolean aBool) {
        this.exponentialMAs = aBool;
    }

    int getNumWorldBits() {
        return this.nworldbits;
    }

    void initWithBaseline(double baseline) {
        this.dividendscale = baseline;
        double initprice = baseline / this.intrate;
        double initdividend = baseline;
        this.saveddividend = this.dividend = baseline;
        this.setDividend(baseline);
        this.savedprice = this.price = initprice;
        this.setPrice(initprice);
        this.returnratio = this.intrate;
        this.profitperunit = 0.0D;
        this.nworldbits = NWORLDBITS;
        this.malength[0] = 5;
        this.malength[1] = 20;
        this.malength[2] = 100;
        this.malength[3] = MAXHISTORY;
        this.history_top = 0;
        this.updown_top = 0;
        this.divhistory = new double[MAXHISTORY];
        this.pricehistory = new double[MAXHISTORY];
        this.realworld = new int[NWORLDBITS];

        int i;
        for(i = 0; i < UPDOWNLOOKBACK; ++i) {
            this.pupdown[i] = 0;
            this.dupdown[i] = 0;
        }

        for(i = 0; i < MAXHISTORY; ++i) {
            this.pricehistory[i] = initprice;
            this.divhistory[i] = initdividend;
        }

        for(i = 0; i < NMAS; ++i) {
            this.priceMA[i] = new MovingAverage();
            this.priceMA[i].initWidth(this.malength[i], initprice);
            this.divMA[i] = new MovingAverage();
            this.divMA[i].initWidth(this.malength[i], initdividend);
            this.oldpriceMA[i] = new MovingAverage();
            this.oldpriceMA[i].initWidth(this.malength[i], initprice);
            this.olddivMA[i] = new MovingAverage();
            this.olddivMA[i].initWidth(this.malength[i], initdividend);
        }

        this.makebitvector();
    }

    void setPrice(double p) {
        this.oldprice = this.price;
        this.price = p;
        this.profitperunit = this.price - this.oldprice + this.dividend;
        if (this.oldprice <= 0.0D) {
            this.returnratio = this.profitperunit * 1000.0D;
        } else {
            this.returnratio = this.profitperunit / this.oldprice;
        }

        this.savedprice = this.price;
    }

    double getPrice() {
        return this.price;
    }

    double getProfitPerUnit() {
        return this.profitperunit;
    }

    void setDividend(double d) {
        this.olddividend = this.dividend;
        this.dividend = d;
        this.saveddividend = this.dividend;
        this.riskNeutral = this.dividend / this.intrate;
    }

    double getDividend() {
        return this.dividend;
    }

    double getRiskNeutral() {
        return this.riskNeutral;
    }

    void updateWorld() {
        this.updown_top = (this.updown_top + 1) % UPDOWNLOOKBACK;
        if (this.price > this.oldprice) {
            this.pupdown[this.updown_top] = 1;
        } else {
            this.pupdown[this.updown_top] = 0;
        }

        if (this.dividend > this.olddividend) {
            this.dupdown[this.updown_top] = 1;
        } else {
            this.dupdown[this.updown_top] = 0;
        }

        this.history_top = this.history_top + 1 + MAXHISTORY;

        for(int i = 0; i < NMAS; ++i) {
            int rago = (this.history_top - this.malength[i]) % MAXHISTORY;
            this.priceMA[i].addValue(this.price);
            this.divMA[i].addValue(this.dividend);
            this.oldpriceMA[i].addValue(this.pricehistory[rago]);
            this.olddivMA[i].addValue(this.divhistory[rago]);
        }

        this.history_top %= MAXHISTORY;
        this.pricehistory[this.history_top] = this.price;
        this.divhistory[this.history_top] = this.dividend;
        this.makebitvector();
    }

    void makebitvector() {
        int i = 0;
        int var11 = i + 1;
        this.realworld[i] = 1;
        this.realworld[var11++] = 0;
        this.realworld[var11++] = (int)(Math.random() * (double)2);
        int temp = this.updown_top + UPDOWNLOOKBACK;

        int j;
        for(j = 0; j < UPDOWNLOOKBACK; --temp) {
            this.realworld[var11++] = this.dupdown[temp % UPDOWNLOOKBACK];
            ++j;
        }

        double temp1;
        double temp2;
        for(j = 0; j < NMAS; ++j) {
            if (this.exponentialMAs) {
                temp1 = this.divMA[j].getEWMA();
                temp2 = this.olddivMA[j].getEWMA();
            } else {
                temp1 = this.divMA[j].getMA();
                temp2 = this.olddivMA[j].getMA();
            }

            if (temp1 > temp2) {
                this.realworld[var11++] = 1;
            } else {
                this.realworld[var11++] = 0;
            }
        }

        for(j = 0; j < NMAS; ++j) {
            if (this.exponentialMAs) {
                temp1 = this.dividend;
                temp2 = this.divMA[j].getEWMA();
            } else {
                temp1 = this.dividend;
                temp2 = this.divMA[j].getMA();
            }

            if (temp1 > temp2) {
                this.realworld[var11++] = 1;
            } else {
                this.realworld[var11++] = 0;
            }
        }

        int k;
        for(j = 0; j < NMAS - 1; ++j) {
            for(k = j + 1; k < NMAS; ++k) {
                if (this.exponentialMAs) {
                    temp1 = this.divMA[j].getEWMA();
                    temp2 = this.divMA[k].getEWMA();
                } else {
                    temp1 = this.divMA[j].getMA();
                    temp2 = this.divMA[k].getMA();
                }

                if (temp1 > temp2) {
                    this.realworld[var11++] = 1;
                } else {
                    this.realworld[var11++] = 0;
                }
            }
        }

        double multiple = this.dividend / this.dividendscale;

        for(j = 0; j < NRATIOS; ++j) {
            if (multiple > this.ratios[j]) {
                this.realworld[var11++] = 1;
            } else {
                this.realworld[var11++] = 0;
            }
        }

        multiple = this.price * this.intrate / this.olddividend;

        for(j = 0; j < NRATIOS; ++j) {
            if (multiple > this.ratios[j]) {
                this.realworld[var11++] = 1;
            } else {
                this.realworld[var11++] = 0;
            }
        }

        temp = this.updown_top + UPDOWNLOOKBACK;

        for(j = 0; j < UPDOWNLOOKBACK; --temp) {
            this.realworld[var11++] = this.pupdown[temp % UPDOWNLOOKBACK];
            ++j;
        }

        for(j = 0; j < NMAS; ++j) {
            if (this.exponentialMAs) {
                temp1 = this.priceMA[j].getEWMA();
                temp2 = this.oldpriceMA[j].getEWMA();
            } else {
                temp1 = this.priceMA[j].getMA();
                temp2 = this.oldpriceMA[j].getMA();
            }

            if (temp1 > temp2) {
                this.realworld[var11++] = 1;
            } else {
                this.realworld[var11++] = 0;
            }
        }

        for(j = 0; j < NMAS; ++j) {
            if (this.exponentialMAs) {
                temp1 = this.priceMA[j].getEWMA();
            } else {
                temp1 = this.priceMA[j].getMA();
            }

            if (this.price > temp1) {
                this.realworld[var11++] = 1;
            } else {
                this.realworld[var11++] = 0;
            }
        }

        for(j = 0; j < NMAS - 1; ++j) {
            for(k = j + 1; k < NMAS; ++k) {
                if (this.exponentialMAs) {
                    temp1 = this.priceMA[j].getEWMA();
                    temp2 = this.priceMA[k].getEWMA();
                } else {
                    temp1 = this.priceMA[j].getMA();
                    temp2 = this.priceMA[k].getMA();
                }

                if (temp1 > temp2) {
                    this.realworld[var11++] = 1;
                } else {
                    this.realworld[var11++] = 0;
                }
            }
        }

    }

    String getRealWorld() {
        String result = "";

        for(int i = 0; i < this.realworld.length; ++i) {
            result = String.valueOf(String.valueOf(result)).concat(String.valueOf(String.valueOf(String.valueOf(this.realworld[i]))));
        }

        return result;
    }

    public void RecordHistory(int currentTime) {
        WorldVariants now_world = new WorldVariants();
        now_world.price = this.price;
        now_world.dividend = this.dividend;
        now_world.currentTime = currentTime;
        now_world.rate = this.intrate;
        now_world.risk_neutral = this.riskNeutral;
        this.Histories.addElement(now_world);
        if (this.Histories.size() > WorldVariants.cycleMax) {
            this.Histories.setElementAt(now_world, this.Histories.size() % WorldVariants.cycleMax);
        }

    }
}
